/* Tiny procedural SFX synth — no audio files needed */

class Sfx {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  muted = false;

  private ensure() {
    if (!this.ctx) {
      const AC = window.AudioContext || (window as any).webkitAudioContext;
      if (!AC) return null;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.42;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") this.ctx.resume();
    return this.ctx;
  }

  init() {
    this.ensure();
  }

  private tone(
    freq: number,
    time: number,
    dur: number,
    type: OscillatorType = "square",
    vol = 1,
    freqEnd?: number
  ) {
    if (this.muted) return;
    const ctx = this.ensure();
    if (!ctx || !this.master) return;
    const t0 = ctx.currentTime + time;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    if (freqEnd !== undefined)
      osc.frequency.exponentialRampToValueAtTime(Math.max(freqEnd, 1), t0 + dur);
    g.gain.setValueAtTime(0, t0);
    g.gain.linearRampToValueAtTime(vol, t0 + 0.008);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    osc.connect(g);
    g.connect(this.master);
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  }

  private noise(time: number, dur: number, vol = 1, lowpass = 1200) {
    if (this.muted) return;
    const ctx = this.ensure();
    if (!ctx || !this.master) return;
    const t0 = ctx.currentTime + time;
    const len = Math.ceil(ctx.sampleRate * dur);
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const filt = ctx.createBiquadFilter();
    filt.type = "lowpass";
    filt.frequency.value = lowpass;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    src.connect(filt);
    filt.connect(g);
    g.connect(this.master);
    src.start(t0);
  }

  jump(big = false) {
    this.tone(big ? 300 : 400, 0, 0.18, "square", 0.5, big ? 900 : 1150);
  }
  coin() {
    this.tone(988, 0, 0.08, "square", 0.35);
    this.tone(1319, 0.08, 0.28, "square", 0.35);
  }
  stomp() {
    this.noise(0, 0.12, 0.5, 900);
    this.tone(420, 0, 0.14, "triangle", 0.7, 90);
  }
  bump() {
    this.tone(160, 0, 0.1, "square", 0.55, 90);
    this.noise(0, 0.08, 0.3, 600);
  }
  sprout() {
    const seq = [392, 523, 659, 784, 1046];
    seq.forEach((f, i) => this.tone(f, i * 0.06, 0.12, "triangle", 0.4));
  }
  power() {
    const seq = [523, 659, 784, 1046, 1319];
    seq.forEach((f, i) => this.tone(f, i * 0.07, 0.16, "square", 0.35));
  }
  hurt() {
    this.tone(500, 0, 0.25, "sawtooth", 0.35, 120);
    this.noise(0, 0.2, 0.3, 700);
  }
  die() {
    const seq = [660, 587, 523, 440, 349, 262];
    seq.forEach((f, i) => this.tone(f, i * 0.1, 0.16, "triangle", 0.45));
  }
  brick() {
    this.noise(0, 0.16, 0.55, 1600);
    this.tone(240, 0, 0.12, "square", 0.4, 60);
  }
  checkpoint() {
    this.tone(784, 0, 0.12, "sine", 0.5);
    this.tone(1046, 0.12, 0.25, "sine", 0.5);
  }
  win() {
    const seq = [523, 659, 784, 1046, 784, 1046, 1319, 1568];
    seq.forEach((f, i) => this.tone(f, i * 0.11, 0.2, "triangle", 0.45));
    seq.forEach((f, i) => this.tone(f / 2, i * 0.11, 0.3, "sine", 0.25));
  }
  whoosh() {
    this.noise(0, 0.1, 0.2, 2400);
  }
}

export const sfx = new Sfx();
