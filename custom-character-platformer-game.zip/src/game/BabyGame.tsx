import { useEffect, useRef, useState, useCallback } from "react";
import {
  Play, Pause, Volume2, VolumeX, Star, Heart, Baby, BedDouble,
  Trophy, RotateCcw, ChevronLeft, ChevronRight, ArrowBigUp, Milk,
  Sparkles, MoonStar, Gamepad2, Home, HandCoins, Copy, Check, CreditCard, X,
} from "lucide-react";
import { Engine, faNum, type GameStatus, type HudState } from "./engine";
import { sfx } from "./audio";

const toFa = faNum;
const borna = ["#ff6b8a", "#ffd166", "#6bd6ff", "#9de88f", "#c79bff", "#ff9d5c", "#7ef0d4", "#ff8fb1"];
const CARD_NUMBER = "6063731210009800";
const CARD_FA = toFa(CARD_NUMBER).replace(/(.{4})/g, "$1 ").trim();

export default function BabyGame() {
  const holderRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const progressRef = useRef<HTMLDivElement>(null);

  const [status, setStatus] = useState<GameStatus>("menu");
  const [hud, setHud] = useState<HudState>({ score: 0, stars: 0, lives: 3, big: false });
  const [muted, setMuted] = useState(false);
  const [paused, setPaused] = useState(false);
  const [coarse, setCoarse] = useState(false);
  const [supportOpen, setSupportOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(pointer: coarse)");
    setCoarse(mq.matches);
    const f = (e: MediaQueryListEvent) => setCoarse(e.matches);
    mq.addEventListener("change", f);
    return () => mq.removeEventListener("change", f);
  }, []);

  useEffect(() => {
    if (!canvasRef.current || !holderRef.current) return;
    const engine = new Engine(canvasRef.current);
    engineRef.current = engine;
    engine.onHud = (h) => setHud(h);
    engine.onStatus = (s) => { setStatus(s); setPaused(false); };
    const onResize = () => engine.resize();
    window.addEventListener("resize", onResize);
    // smooth progress bar
    let raf = 0;
    const tick = () => {
      if (progressRef.current && engineRef.current) {
        const p = engineRef.current.progress();
        progressRef.current.style.left = `${4 + p * 88}%`;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => {
      window.removeEventListener("resize", onResize);
      cancelAnimationFrame(raf);
      engine.destroy();
      engineRef.current = null;
    };
  }, []);

  const start = useCallback(() => {
    sfx.init();
    engineRef.current?.start();
  }, []);

  const togglePause = () => {
    engineRef.current?.pauseToggle();
    setPaused((p) => (engineRef.current?.status === "play" ? !p : p));
  };
  const toggleMute = () => { sfx.muted = !sfx.muted; setMuted(sfx.muted); };

  const copyCard = async () => {
    try {
      await navigator.clipboard.writeText(CARD_NUMBER);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = CARD_NUMBER;
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand("copy"); } catch { /* noop */ }
      ta.remove();
    }
    setCopied(true);
    sfx.coin();
    window.setTimeout(() => setCopied(false), 2200);
  };

  const setTouch = (k: "left" | "right" | "jump", v: boolean) => {
    const e = engineRef.current;
    if (e) e.touch = { ...e.touch, [k]: v };
  };

  const best = Number(localStorage.getItem("nini-best") || 0);
  const playing = status === "play";

  return (
    <div className="font-game relative h-[100dvh] w-full overflow-hidden" dir="rtl">
      {/* game canvas */}
      <div ref={holderRef} className="absolute inset-0">
        <canvas ref={canvasRef} className="h-full w-full" />
      </div>

      {/* ==================== HUD ==================== */}
      {(playing || status === "dead" || status === "winanim") && (
        <>
          <div className="pointer-events-none absolute right-3 top-3 z-20 flex flex-col gap-2 sm:right-5 sm:top-5">
            <div className="flex gap-2">
              <div className="hud-chip anim-pop-in text-base sm:text-lg">
                <Sparkles className="h-5 w-5 text-amber-400" />
                <span>{toFa(hud.score)}</span>
              </div>
              <div className="hud-chip anim-pop-in text-base sm:text-lg" style={{ animationDelay: "0.06s" }}>
                <Star className="h-5 w-5 fill-amber-400 text-amber-400" />
                <span>{toFa(hud.stars)}</span>
              </div>
              {hud.big && (
                <div className="hud-chip anim-pop-in text-base text-pink-500 sm:text-lg">
                  <Milk className="h-5 w-5" />
                  <span>تپلی!</span>
                </div>
              )}
            </div>
            <div className="flex gap-1.5 pr-1">
              {[0, 1, 2].map((i) => (
                <Heart
                  key={i}
                  className={`h-6 w-6 drop-shadow anim-bounce-soft transition-all duration-300 ${
                    hud.lives > i ? "fill-rose-500 text-rose-500" : "fill-slate-300/70 text-slate-300/70 scale-75"
                  }`}
                  style={{ animationDelay: `${i * 0.2}s` }}
                />
              ))}
            </div>
          </div>

          {/* top-left controls */}
          <div className="absolute left-3 top-3 z-20 flex gap-2 sm:left-5 sm:top-5">
            <button onClick={togglePause} className="pad !h-12 !w-12 !rounded-2xl" aria-label="pause">
              <Pause className="h-5 w-5" />
            </button>
            <button onClick={toggleMute} className="pad !h-12 !w-12 !rounded-2xl" aria-label="mute">
              {muted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
            </button>
          </div>

          {/* progress bar */}
          <div className="pointer-events-none absolute bottom-3 left-1/2 z-20 w-[min(420px,72vw)] -translate-x-1/2 sm:bottom-5">
            <div className="relative h-5 rounded-full border-2 border-white/90 bg-white/60 shadow-[0_4px_0_rgba(120,170,220,0.25),inset_0_2px_4px_rgba(120,170,220,0.2)] backdrop-blur">
              <div className="absolute inset-y-1 right-1 left-1 overflow-hidden rounded-full">
                <div className="h-full w-full rounded-full bg-gradient-to-l from-sky-200/60 to-amber-200/60" />
              </div>
              <div ref={progressRef} className="absolute -top-3.5" style={{ left: "4%", transform: "translateX(-50%)" }}>
                <div className="grid h-9 w-9 place-items-center rounded-full border-2 border-white bg-gradient-to-b from-rose-300 to-rose-400 text-white shadow-lg anim-bob">
                  <Baby className="h-5 w-5" />
                </div>
              </div>
              <div className="absolute -top-2.5 left-full -translate-x-1/2">
                <div className="grid h-7 w-7 place-items-center rounded-full border-2 border-white bg-gradient-to-b from-emerald-300 to-emerald-400 text-white shadow-md">
                  <BedDouble className="h-4 w-4" />
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {/* ==================== touch controls ==================== */}
      {coarse && playing && !paused && (
        <div className="absolute inset-x-0 bottom-14 z-30 flex items-end justify-between px-4 sm:bottom-16" dir="ltr">
          <div className="flex gap-3">
            <button
              className="pad"
              onPointerDown={(e) => { e.preventDefault(); (e.target as HTMLElement).setPointerCapture(e.pointerId); setTouch("left", true); }}
              onPointerUp={() => setTouch("left", false)}
              onPointerCancel={() => setTouch("left", false)}
              onPointerLeave={() => setTouch("left", false)}
            >
              <ChevronLeft className="h-8 w-8" />
            </button>
            <button
              className="pad"
              onPointerDown={(e) => { e.preventDefault(); (e.target as HTMLElement).setPointerCapture(e.pointerId); setTouch("right", true); }}
              onPointerUp={() => setTouch("right", false)}
              onPointerCancel={() => setTouch("right", false)}
              onPointerLeave={() => setTouch("right", false)}
            >
              <ChevronRight className="h-8 w-8" />
            </button>
          </div>
          <button
            className="pad pad-jump"
            onPointerDown={(e) => { e.preventDefault(); (e.target as HTMLElement).setPointerCapture(e.pointerId); setTouch("jump", true); }}
            onPointerUp={() => setTouch("jump", false)}
            onPointerCancel={() => setTouch("jump", false)}
            onPointerLeave={() => setTouch("jump", false)}
          >
            <ArrowBigUp className="h-10 w-10" />
          </button>
        </div>
      )}

      {/* ==================== MENU ==================== */}
      {status === "menu" && (
        <div className="anim-fade-in absolute inset-0 z-40 flex items-end justify-center bg-gradient-to-b from-sky-400/30 via-transparent to-sky-900/25 p-4 pb-8 sm:items-center sm:pb-4">
          {/* twinkles */}
          {[...Array(8)].map((_, i) => (
            <Sparkles
              key={i}
              className="anim-twinkle pointer-events-none absolute text-white/80"
              style={{ top: `${8 + ((i * 29) % 40)}%`, left: `${(i * 13) % 92}%`, animationDelay: `${i * 0.3}s` }}
            />
          ))}
          <div className="anim-pop-in w-full max-w-md rounded-[2.5rem] border-4 border-white/90 bg-white/75 p-6 text-center shadow-[0_10px_0_rgba(120,170,220,0.3),0_30px_60px_rgba(60,110,180,0.3)] backdrop-blur-xl sm:p-8">
            <div className="mx-auto -mt-16 mb-2 grid h-24 w-24 place-items-center rounded-[2rem] border-4 border-white bg-gradient-to-b from-rose-200 to-rose-300 shadow-lg anim-bounce-soft">
              <Baby className="h-14 w-14 text-white drop-shadow" />
            </div>
            <h1 className="text-4xl font-black leading-tight text-sky-900 sm:text-5xl">
              ماجراجویی <span className="bg-gradient-to-l from-rose-400 to-amber-400 bg-clip-text text-transparent">نی‌نی</span>
            </h1>
            <p className="mt-2 text-sm font-bold leading-6 text-sky-800/80 sm:text-base">
              با نی‌نوی قلبی از روی اسباب‌بازی‌ها بپر، ستاره‌ها و بطری شیر جمع کن
              و سرِ راه به گهواره‌ی گرم برس!
            </p>

            <div className="mt-4 flex flex-wrap items-center justify-center gap-x-3 gap-y-2 text-xs font-bold text-sky-800/90 sm:text-sm">
              <span className="flex items-center gap-1.5 rounded-full bg-white/70 px-3 py-1.5">
                <Gamepad2 className="h-4 w-4 text-sky-500" /> حرکت:
                <kbd className="key">→</kbd><kbd className="key">←</kbd>
              </span>
              <span className="flex items-center gap-1.5 rounded-full bg-white/70 px-3 py-1.5">
                پرش: <kbd className="key">Space</kbd>
              </span>
              <span className="flex items-center gap-1.5 rounded-full bg-white/70 px-3 py-1.5">
                روی اسباب‌بازی‌ها بپر تا له بشن!
              </span>
            </div>

            <button onClick={start} className="btn-candy mt-5 flex w-full items-center justify-center gap-2 px-8 py-4 text-2xl">
              <Play className="h-7 w-7 fill-white" />
              شروع بازی
            </button>
            {best > 0 && (
              <div className="mt-3 inline-flex items-center gap-2 rounded-full bg-amber-100/80 px-4 py-1.5 text-sm font-black text-amber-700">
                <Trophy className="h-4 w-4" /> رکورد: {toFa(best)}
              </div>
            )}

            <button
              onClick={() => setSupportOpen(true)}
              className="btn-mint mt-3 flex w-full items-center justify-center gap-2 px-6 py-3 text-base"
            >
              <HandCoins className="h-5 w-5" />
              حمایت از سازنده
              <Heart className="h-4 w-4 fill-rose-400 text-rose-400" style={{ animation: "float-heart 1.6s ease-in-out infinite" }} />
            </button>
            <p className="mt-2 text-[11px] font-bold text-sky-800/50">اگه بازی رو دوست داشتی، یه شیرِ خونگی مهمانمون کن</p>
          </div>
        </div>
      )}

      {/* ==================== PAUSE ==================== */}
      {paused && status === "play" && (
        <div className="anim-fade-in absolute inset-0 z-40 grid place-items-center bg-sky-900/30 p-4 backdrop-blur-sm">
          <div className="anim-pop-in w-full max-w-xs rounded-[2rem] border-4 border-white bg-white/90 p-6 text-center shadow-2xl">
            <h2 className="text-2xl font-black text-sky-900">استراحت کوچولو</h2>
            <p className="mt-1 text-sm font-bold text-sky-700/70">نی‌نی داره چشماتکی می‌زنه...</p>
            <button onClick={togglePause} className="btn-candy mt-4 flex w-full items-center justify-center gap-2 px-6 py-3 text-xl">
              <Play className="h-6 w-6 fill-white" /> ادامه بده
            </button>
            <button
              onClick={() => { engineRef.current?.pauseToggle(); setPaused(false); engineRef.current && (engineRef.current.status = "menu"); setStatus("menu"); }}
              className="btn-mint mt-2 flex w-full items-center justify-center gap-2 px-6 py-3 text-base"
            >
              <Home className="h-5 w-5" /> برگرد به خانه
            </button>
          </div>
        </div>
      )}

      {/* ==================== GAME OVER ==================== */}
      {status === "over" && (
        <div className="anim-fade-in absolute inset-0 z-40 grid place-items-center bg-gradient-to-b from-indigo-400/40 to-indigo-900/40 p-4 backdrop-blur-[3px]">
          <div className="anim-pop-in w-full max-w-sm rounded-[2.5rem] border-4 border-white bg-white/90 p-7 text-center shadow-2xl">
            <div className="mx-auto -mt-16 mb-2 grid h-20 w-20 place-items-center rounded-full border-4 border-white bg-gradient-to-b from-indigo-200 to-indigo-300 anim-bob">
              <MoonStar className="h-10 w-10 text-indigo-500" />
            </div>
            <h2 className="text-3xl font-black text-indigo-900">نی‌نی خوابش اومد!</h2>
            <p className="mt-1 text-sm font-bold text-indigo-700/70">یه کم دیگه تمرین، بعد دوباره می‌دویم</p>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <div className="rounded-2xl bg-sky-50 p-3 ring-2 ring-sky-100">
                <div className="text-xs font-bold text-sky-500">امتیاز</div>
                <div className="text-2xl font-black text-sky-800">{toFa(hud.score)}</div>
              </div>
              <div className="rounded-2xl bg-amber-50 p-3 ring-2 ring-amber-100">
                <div className="flex items-center justify-center gap-1 text-xs font-bold text-amber-500"><Trophy className="h-3.5 w-3.5" /> رکورد</div>
                <div className="text-2xl font-black text-amber-700">{toFa(best)}</div>
              </div>
            </div>
            <button onClick={start} className="btn-candy mt-5 flex w-full items-center justify-center gap-2 px-6 py-3.5 text-xl">
              <RotateCcw className="h-6 w-6" /> دوباره بازی کن
            </button>
          </div>
        </div>
      )}

      {/* ==================== WIN ==================== */}
      {status === "win" && (
        <div className="anim-fade-in absolute inset-0 z-40 grid place-items-center overflow-hidden bg-gradient-to-b from-emerald-300/40 to-sky-300/40 p-4 backdrop-blur-[3px]">
          {[...Array(24)].map((_, i) => (
            <div
              key={i}
              className="confetti"
              style={{
                left: `${(i * 37) % 100}%`,
                top: "-20px",
                background: borna[i % borna.length],
                animationDuration: `${2.4 + (i % 5) * 0.55}s`,
                animationDelay: `${(i % 7) * 0.35}s`,
                transform: `rotate(${i * 47}deg)`,
              }}
            />
          ))}
          <div className="anim-pop-in relative w-full max-w-sm rounded-[2.5rem] border-4 border-white bg-white/90 p-7 text-center shadow-2xl">
            <div className="mx-auto -mt-16 mb-2 grid h-20 w-20 place-items-center rounded-full border-4 border-white bg-gradient-to-b from-amber-200 to-amber-300 anim-wiggle">
              <BedDouble className="h-10 w-10 text-amber-600" />
            </div>
            <h2 className="text-3xl font-black text-emerald-700">هورااا!</h2>
            <p className="mt-1 text-sm font-bold text-emerald-700/70">
              نی‌نی سالم و خوشحال به گهواره رسید
            </p>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <div className="rounded-2xl bg-sky-50 p-3 ring-2 ring-sky-100">
                <div className="text-xs font-bold text-sky-500">امتیاز</div>
                <div className="text-2xl font-black text-sky-800">{toFa(hud.score)}</div>
              </div>
              <div className="rounded-2xl bg-amber-50 p-3 ring-2 ring-amber-100">
                <div className="flex items-center justify-center gap-1 text-xs font-bold text-amber-500">
                  <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" /> ستاره
                </div>
                <div className="text-2xl font-black text-amber-700">{toFa(hud.stars)}</div>
              </div>
            </div>
            {hud.score >= best && hud.score > 0 && (
              <div className="anim-twinkle mx-auto mt-3 inline-flex items-center gap-2 rounded-full bg-rose-100 px-4 py-1.5 text-sm font-black text-rose-600">
                <Sparkles className="h-4 w-4" /> رکورد جدید زدی!
              </div>
            )}
            <button onClick={start} className="btn-candy mt-5 flex w-full items-center justify-center gap-2 px-6 py-3.5 text-xl">
              <RotateCcw className="h-6 w-6" /> یه دور دیگه
            </button>
            <button
              onClick={() => setSupportOpen(true)}
              className="mt-2 flex w-full items-center justify-center gap-1.5 rounded-full px-4 py-2 text-sm font-black text-emerald-600 transition hover:bg-emerald-50"
            >
              <HandCoins className="h-4 w-4" /> برنده شدی؟ یه حمایت کوچولو!
            </button>
          </div>
        </div>
      )}

      {/* ==================== SUPPORT / DONATE ==================== */}
      {supportOpen && (
        <div
          className="anim-fade-in absolute inset-0 z-50 grid place-items-center bg-sky-950/45 p-4 backdrop-blur-sm"
          onClick={() => setSupportOpen(false)}
        >
          {[...Array(10)].map((_, i) => (
            <Heart
              key={i}
              className="anim-twinkle pointer-events-none absolute fill-rose-300/70 text-rose-300/70"
              style={{ top: `${(i * 17) % 88}%`, left: `${(i * 23) % 92}%`, width: 14 + (i % 3) * 8, height: 14 + (i % 3) * 8, animationDelay: `${i * 0.25}s` }}
            />
          ))}
          <div
            className="anim-pop-in relative w-full max-w-sm rounded-[2.5rem] border-4 border-white bg-white/95 p-6 text-center shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSupportOpen(false)}
              className="absolute left-4 top-4 grid h-9 w-9 place-items-center rounded-full bg-slate-100 text-slate-500 transition hover:bg-slate-200"
              aria-label="بستن"
            >
              <X className="h-5 w-5" />
            </button>
            <div className="mx-auto mb-3 grid h-16 w-16 place-items-center rounded-[1.4rem] bg-gradient-to-b from-rose-200 to-rose-300 anim-bounce-soft">
              <HandCoins className="h-8 w-8 text-white drop-shadow" />
            </div>
            <h2 className="text-2xl font-black text-sky-900">حمایت از سازنده</h2>
            <p className="mt-1 text-sm font-bold leading-6 text-sky-700/70">
              اگه از بازی کردنِ نی‌نی خوشت اومد،
              می‌تونی با کارت‌به‌کارت مارو خوشحال کنی
            </p>

            {/* dreamy bank card */}
            <div className="relative mt-5 overflow-hidden rounded-3xl bg-gradient-to-br from-violet-400 via-rose-300 to-amber-200 p-5 text-white shadow-[0_14px_30px_rgba(200,120,180,0.35)]" dir="ltr">
              <div className="pointer-events-none absolute -right-6 -top-8 h-28 w-28 rounded-full bg-white/25" />
              <div className="pointer-events-none absolute -bottom-10 -left-4 h-32 w-32 rounded-full bg-white/20" />
              <div className="flex items-center justify-between">
                <CreditCard className="h-7 w-7 opacity-90" />
                <span className="text-[11px] font-black tracking-wide opacity-90">کارت‌به‌کارت</span>
              </div>
              <div className="mt-6 font-mono text-xl font-black tracking-[0.14em] drop-shadow-sm sm:text-2xl">
                {CARD_NUMBER.replace(/(.{4})/g, "$1 ")}
              </div>
              <div className="mt-3 flex items-center justify-between text-[11px] font-bold opacity-90" dir="rtl">
                <span>شماره کارت سازنده‌ی بازی</span>
                <span className="flex items-center gap-1"><Star className="h-3.5 w-3.5 fill-white" /> ممنون از لطفت!</span>
              </div>
            </div>

            <div className="mt-3 rounded-2xl bg-sky-50 px-4 py-2.5 text-sm font-black tracking-wider text-sky-800 ring-2 ring-sky-100" dir="ltr">
              {CARD_FA}
            </div>

            <button
              onClick={copyCard}
              className={`mt-4 flex w-full items-center justify-center gap-2 rounded-full border-[3px] border-white/70 px-6 py-3.5 text-lg font-black text-white transition-all duration-200 ${
                copied
                  ? "bg-gradient-to-b from-emerald-400 to-emerald-500 shadow-[0_6px_0_#0f9d6c,0_14px_30px_rgba(16,185,129,0.4)]"
                  : "bg-gradient-to-b from-violet-400 to-fuchsia-500 shadow-[0_6px_0_#a21caf,0_14px_30px_rgba(192,38,211,0.4)] hover:-translate-y-0.5 active:translate-y-1 active:shadow-[0_2px_0_#a21caf]"
              }`}
            >
              {copied ? (
                <>
                  <Check className="h-6 w-6" /> کپی شد، دمت گرم!
                </>
              ) : (
                <>
                  <Copy className="h-6 w-6" /> کپی شماره کارت
                </>
              )}
            </button>
            <p className="mt-2 text-[11px] font-bold leading-5 text-sky-800/50">
              شماره کارت کپی می‌شه؛ بعد داخل اپلیکیشن بانکت «کارت به کارت» رو بزن
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
