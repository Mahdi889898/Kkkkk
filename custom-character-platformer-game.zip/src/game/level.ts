/* Level construction — built programmatically, hand-tuned course */

export const TILE = 48;
export const ROWS = 12;
export const GROUND_ROW = 10; // top row of the ground

export const T = {
  EMPTY: 0,
  GROUND: 1,
  BRICK: 2,
  QUESTION: 3,
  USED: 4,
  PLANK: 5,
  PIPE: 6,
} as const;

export interface CoinDef {
  tx: number;
  ty: number;
}
export interface EnemyDef {
  tx: number;
  ty: number;
}
export interface CheckpointDef {
  x: number; // world px
  taken: boolean;
}
export interface LevelData {
  cols: number;
  rows: number;
  grid: Uint8Array;
  coins: CoinDef[];
  enemies: EnemyDef[];
  checkpoints: CheckpointDef[];
  finishX: number; // world px, center of crib
  startX: number;
  startY: number;
}

const COLS = 190;

export function buildLevel(): LevelData {
  const grid = new Uint8Array(COLS * ROWS);
  const coins: CoinDef[] = [];
  const enemies: EnemyDef[] = [];
  const checkpoints: CheckpointDef[] = [];

  const set = (tx: number, ty: number, v: number) => {
    if (tx >= 0 && tx < COLS && ty >= 0 && ty < ROWS) grid[ty * COLS + tx] = v;
  };

  const ground = (a: number, b: number) => {
    for (let x = a; x <= b; x++) {
      set(x, GROUND_ROW, T.GROUND);
      set(x, GROUND_ROW + 1, T.GROUND);
    }
  };
  const pipe = (x: number, h: number) => {
    for (let i = 0; i < h; i++) set(x, GROUND_ROW - 1 - i, T.PIPE);
  };
  const bricks = (row: number, ...cells: [number, number][]) => {
    for (const [x, v] of cells) set(x, row, v);
  };
  const plank = (row: number, a: number, b: number) => {
    for (let x = a; x <= b; x++) set(x, row, T.PLANK);
  };
  const coinRow = (row: number, a: number, b: number) => {
    for (let x = a; x <= b; x++) coins.push({ tx: x, ty: row });
  };
  const coinArc = (startX: number, baseRow: number) => {
    const offs = [0, -1, -2, -1, 0];
    offs.forEach((o, i) => coins.push({ tx: startX + i, ty: baseRow + o }));
  };
  const stairs = (x: number, heights: number[]) => {
    heights.forEach((h, i) => {
      for (let j = 0; j < h; j++) set(x + i, GROUND_ROW - 1 - j, T.GROUND);
    });
  };
  const foe = (tx: number) => enemies.push({ tx, ty: GROUND_ROW - 1 });

  /* ================= SECTION A — gentle intro ================= */
  ground(0, 43);
  coinArc(9, 7);
  bricks(8, [18, T.BRICK], [19, T.QUESTION], [20, T.BRICK]);
  coins.push({ tx: 19, ty: 5 });
  plank(6, 24, 27);
  coinRow(5, 25, 26);
  coinRow(7, 30, 32);
  pipe(36, 2);
  pipe(41, 3);
  foe(15); foe(22); foe(30); foe(34);

  /* ================= SECTION B — first pit & stairs ================= */
  coinArc(43, 6); // over pit 44..46
  ground(47, 76);
  stairs(51, [1, 2, 3]);
  plank(6, 55, 58);
  coinRow(5, 56, 57);
  checkpoints.push({ x: 60 * TILE, taken: false });
  bricks(8, [63, T.BRICK], [64, T.QUESTION], [65, T.BRICK], [66, T.QUESTION]);
  coins.push({ tx: 64, ty: 5 }, { tx: 66, ty: 5 });
  pipe(69, 2);
  pipe(72, 3);
  foe(50); foe(62); foe(68); foe(74);

  /* ================= SECTION C — floating isles ================= */
  // pit 77..80
  plank(7, 78, 79);
  coins.push({ tx: 78, ty: 5 }, { tx: 79, ty: 5 });
  ground(81, 120);
  bricks(8, [84, T.QUESTION], [85, T.BRICK]);
  coins.push({ tx: 84, ty: 5 });
  plank(8, 88, 89);
  plank(6, 91, 92);
  coins.push({ tx: 91, ty: 4 }, { tx: 92, ty: 4 });
  checkpoints.push({ x: 100 * TILE, taken: false });
  bricks(8, [103, T.BRICK], [104, T.QUESTION]);
  coinRow(7, 103, 104);
  pipe(108, 2);
  pipe(111, 3);
  pipe(114, 2);
  foe(86); foe(90); foe(96); foe(105); foe(118);

  /* ================= SECTION D — sky bridge ================= */
  // pit 121..124
  plank(7, 122, 123);
  coinRow(5, 122, 123);
  ground(125, 150);
  bricks(8, [130, T.QUESTION], [140, T.BRICK], [141, T.QUESTION], [142, T.BRICK]);
  coins.push({ tx: 141, ty: 5 });
  pipe(146, 2);
  foe(128); foe(132); foe(136);

  /* ================= SECTION E — final stretch ================= */
  // pit 151..153
  coinArc(150, 6);
  ground(154, 186);
  coinRow(7, 156, 159);
  bricks(8, [162, T.QUESTION]);
  coinRow(7, 161, 164);
  foe(166); foe(170); foe(174);

  // end wall
  for (let y = 6; y < ROWS; y++) {
    set(188, y, T.GROUND);
    set(189, y, T.GROUND);
  }

  return {
    cols: COLS,
    rows: ROWS,
    grid,
    coins,
    enemies,
    checkpoints,
    finishX: 181 * TILE,
    startX: 2.5 * TILE,
    startY: (GROUND_ROW - 2) * TILE,
  };
}
