/* ============================================================
   «ماجراجویی نی‌نی» — Mario-style platformer engine
   The hero is a fully hand-drawn baby (canvas vector art):
   cream bow headband, big blue eyes, white fluffy onesie.
   ============================================================ */

import { buildLevel, TILE, ROWS, GROUND_ROW, T, type LevelData } from "./level";
import { sfx } from "./audio";

export type GameStatus = "menu" | "play" | "dead" | "winanim" | "over" | "win";

export interface HudState {
  score: number;
  stars: number;
  lives: number;
  big: boolean;
}

export const faNum = (n: number | string) =>
  String(n).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[+d]);

/* ---------------- collision helpers ---------------- */
const overlap = (
  ax: number, ay: number, aw: number, ah: number,
  bx: number, by: number, bw: number, bh: number
) => ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;

/* ============================================================
   SPRITE PAINTERS — everything is drawn with love & <canvas>
   ============================================================ */

const OUTLINE = "rgba(146,92,62,0.6)";
const SKIN = "#ffe7d6";
const SKIN_SHADE = "#ffd8c2";
const BLUSH = "rgba(255,138,128,0.5)";
const BAND = "#f7efdd";
const WHITE = "#fffdf8";
const HAIR = "#e9b96c";
const BLUE = "#4d9bd6";

function roundRect(
  ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/** Draws the baby (facing right) into a canvas. baseLine = bottom (feet). */
function paintBaby(
  ctx: CanvasRenderingContext2D,
  h: number,
  opts: { frame: "stand" | "run0" | "run1" | "jump"; blink: boolean }
) {
  const s = h / 150; // logical unit scale
  ctx.save();
  ctx.scale(s, s);
  ctx.lineWidth = 2.4;
  ctx.strokeStyle = OUTLINE;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";

  const { frame } = opts;
  const legSwing = frame === "run0" ? 1 : frame === "run1" ? -1 : 0;
  const tucked = frame === "jump";

  /* ---- back arm ---- */
  ctx.save();
  ctx.translate(52, 100);
  ctx.rotate((frame === "jump" ? -0.9 : -0.35 * legSwing) - 0.15);
  ctx.fillStyle = WHITE;
  ctx.beginPath();
  ctx.ellipse(0, 9, 8, 13, 0, 0, Math.PI * 2);
  ctx.fill(); ctx.stroke();
  ctx.restore();

  /* ---- legs ---- */
  const drawLeg = (side: number, phase: number) => {
    ctx.save();
    ctx.translate(80 + side * 13, 118);
    const rot = tucked ? -0.75 * side : 0.55 * phase * side;
    ctx.rotate(rot);
    ctx.fillStyle = WHITE;
    ctx.beginPath();
    ctx.ellipse(0, 12, 8.5, 15, 0, 0, Math.PI * 2);
    ctx.fill(); ctx.stroke();
    // bootie foot
    ctx.fillStyle = "#fdf3e4";
    ctx.beginPath();
    ctx.ellipse(tucked ? 8 : 9, 24, 10, 6.5, -0.35, 0, Math.PI * 2);
    ctx.fill(); ctx.stroke();
    ctx.restore();
  };
  drawLeg(-1, legSwing || 0.12);
  drawLeg(1, legSwing || -0.12);

  /* ---- body: fluffy white onesie ---- */
  ctx.fillStyle = WHITE;
  ctx.beginPath();
  ctx.ellipse(80, 106, 33, 30, 0, 0, Math.PI * 2);
  ctx.fill(); ctx.stroke();
  // onesie shading + collar
  ctx.fillStyle = "rgba(210,225,245,0.55)";
  ctx.beginPath();
  ctx.ellipse(80, 122, 26, 12, 0, 0, Math.PI);
  ctx.fill();
  ctx.strokeStyle = "rgba(146,92,62,0.35)";
  ctx.beginPath();
  ctx.ellipse(80, 84, 14, 7, 0, 0, Math.PI);
  ctx.stroke();
  ctx.strokeStyle = OUTLINE;

  /* ---- head ---- */
  const hy = 54, hr = 41;
  // ears
  ctx.fillStyle = SKIN;
  ctx.beginPath(); ctx.arc(80 - hr + 3, hy + 6, 7, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.arc(80 + hr - 3, hy + 6, 7, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  // face ball
  ctx.beginPath(); ctx.arc(80, hy, hr, 0, Math.PI * 2);
  ctx.fillStyle = SKIN; ctx.fill();
  ctx.stroke();
  // subtle chin shade
  ctx.fillStyle = SKIN_SHADE;
  ctx.beginPath(); ctx.ellipse(80, hy + hr - 6, 18, 7, 0, 0, Math.PI); ctx.fill();

  /* ---- headband with the signature white bow ---- */
  ctx.fillStyle = BAND;
  ctx.beginPath();
  ctx.arc(80, hy, hr, Math.PI * 1.18, Math.PI * 1.82);
  ctx.arc(80, hy + 3, hr - 11, Math.PI * 1.85, Math.PI * 1.15, true);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  // tiny heart print on band
  ctx.fillStyle = "rgba(157,190,235,0.7)";
  for (const dx of [-18, 0, 18]) {
    ctx.save();
    ctx.translate(80 + dx, hy - hr + 13 - Math.abs(dx) * 0.22);
    ctx.scale(0.7, 0.7);
    ctx.beginPath();
    ctx.moveTo(0, 3);
    ctx.bezierCurveTo(-5, -2, -2, -7, 0, -3.5);
    ctx.bezierCurveTo(2, -7, 5, -2, 0, 3);
    ctx.fill();
    ctx.restore();
  }
  // the bow — two puffy loops + knot, upper-left
  ctx.save();
  ctx.translate(56, hy - hr + 4);
  ctx.fillStyle = WHITE;
  ctx.strokeStyle = "rgba(146,92,62,0.5)";
  ctx.save(); ctx.rotate(-0.5);
  ctx.beginPath(); ctx.ellipse(-11, 0, 13.5, 9, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.restore();
  ctx.save(); ctx.rotate(0.35);
  ctx.beginPath(); ctx.ellipse(11, -2, 13.5, 9, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.restore();
  ctx.beginPath(); ctx.arc(0, 0, 5.5, 0, Math.PI * 2);
  ctx.fillStyle = "#f0f6ff"; ctx.fill(); ctx.stroke();
  // bow tails
  ctx.beginPath(); ctx.ellipse(-3, 12, 4, 9, 0.25, 0, Math.PI * 2);
  ctx.fillStyle = WHITE; ctx.fill(); ctx.stroke();
  ctx.restore();
  ctx.strokeStyle = OUTLINE;

  /* ---- blonde curl wisp ---- */
  ctx.strokeStyle = HAIR;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(80, hy - hr + 10);
  ctx.bezierCurveTo(92, hy - hr + 14, 90, hy - hr + 24, 82, hy - hr + 22);
  ctx.bezierCurveTo(76, hy - hr + 21, 77, hy - hr + 14, 84, hy - hr + 16);
  ctx.stroke();
  ctx.strokeStyle = OUTLINE;
  ctx.lineWidth = 2.4;

  /* ---- face ---- */
  // blush
  ctx.fillStyle = BLUSH;
  ctx.beginPath(); ctx.ellipse(56, hy + 14, 7.5, 5.5, 0, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.ellipse(104, hy + 14, 7.5, 5.5, 0, 0, Math.PI * 2); ctx.fill();

  const drawEye = (cx: number, cy: number, bigHalf: boolean) => {
    if (opts.blink) {
      ctx.beginPath();
      ctx.arc(cx, cy, bigHalf ? 9 : 7.5, Math.PI * 0.15, Math.PI * 0.85);
      ctx.strokeStyle = "#8a5a44";
      ctx.lineWidth = 2.6;
      ctx.stroke();
      ctx.strokeStyle = OUTLINE; ctx.lineWidth = 2.4;
      return;
    }
    const rx = bigHalf ? 8.4 : 7.2, ry = bigHalf ? 10.6 : 9.4;
    ctx.fillStyle = "#ffffff";
    ctx.beginPath(); ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    // iris + pupil, looking forward-right
    ctx.fillStyle = BLUE;
    ctx.beginPath(); ctx.arc(cx + 2.2, cy + 1, rx * 0.68, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#1c2b45";
    ctx.beginPath(); ctx.arc(cx + 2.8, cy + 1.2, rx * 0.4, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#fff";
    ctx.beginPath(); ctx.arc(cx + 0.4, cy - 2.4, 2.4, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(cx + 4.6, cy + 3.4, 1.2, 0, Math.PI * 2); ctx.fill();
  };
  drawEye(64, hy - 2, false);
  drawEye(97, hy - 2, true);

  // lashes
  ctx.strokeStyle = "#8a5a44";
  ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(56, hy - 12); ctx.lineTo(51, hy - 15); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(105, hy - 12); ctx.lineTo(110, hy - 15); ctx.stroke();
  // soft brows
  ctx.strokeStyle = "rgba(214,160,102,0.75)";
  ctx.lineWidth = 2.6;
  ctx.beginPath(); ctx.arc(64, hy - 14, 8, Math.PI * 1.15, Math.PI * 1.85); ctx.stroke();
  ctx.beginPath(); ctx.arc(97, hy - 15, 8, Math.PI * 1.15, Math.PI * 1.85); ctx.stroke();
  ctx.strokeStyle = OUTLINE; ctx.lineWidth = 2.4;

  // nose
  ctx.fillStyle = "#f5b98f";
  ctx.beginPath(); ctx.ellipse(81, hy + 9, 3.4, 2.8, 0, 0, Math.PI * 2); ctx.fill();
  // mouth
  if (frame === "jump") {
    ctx.fillStyle = "#a84e3f";
    ctx.beginPath(); ctx.ellipse(80, hy + 21, 4.6, 5.4, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#e88a7a";
    ctx.beginPath(); ctx.ellipse(80, hy + 23.4, 2.6, 2.4, 0, 0, Math.PI * 2); ctx.fill();
  } else {
    ctx.strokeStyle = "#b3503f";
    ctx.lineWidth = 2.6;
    ctx.beginPath(); ctx.arc(80, hy + 15, 7, Math.PI * 0.25, Math.PI * 0.75); ctx.stroke();
    ctx.strokeStyle = OUTLINE; ctx.lineWidth = 2.4;
  }

  /* ---- front arm ---- */
  ctx.save();
  ctx.translate(108, 100);
  ctx.rotate(tucked ? 0.9 : 0.4 * legSwing + 0.15);
  ctx.fillStyle = WHITE;
  ctx.beginPath(); ctx.ellipse(0, 9, 8, 13, 0, 0, Math.PI * 2);
  ctx.fill(); ctx.stroke();
  ctx.restore();

  ctx.restore();
}

/* --- enemy: grumpy wind-up toy block --- */
function paintToyEnemy(ctx: CanvasRenderingContext2D, size: number, frame: number, dead: boolean) {
  const s = size / 44;
  ctx.save();
  ctx.scale(s, s);
  if (dead) ctx.scale(1.15, 0.35);
  ctx.lineWidth = 2.4;
  ctx.strokeStyle = "rgba(120,52,52,0.55)";
  ctx.lineJoin = "round";
  // feet
  ctx.fillStyle = "#5b3a4e";
  const f = frame === 0 ? 0 : 3;
  ctx.beginPath(); ctx.ellipse(10 + f, 40, 6, 4, 0, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.ellipse(34 - f, 40, 6, 4, 0, 0, Math.PI * 2); ctx.fill();
  // body
  const g = ctx.createLinearGradient(0, 0, 0, 40);
  g.addColorStop(0, "#ff9d8f");
  g.addColorStop(1, "#f2604f");
  ctx.fillStyle = g;
  roundRect(ctx, 3, 4, 38, 36, 8);
  ctx.fill(); ctx.stroke();
  // wind-up key
  ctx.strokeStyle = "#b8c7dd";
  ctx.lineWidth = 2.2;
  ctx.beginPath(); ctx.moveTo(3, 14); ctx.lineTo(-4, 14); ctx.stroke();
  ctx.beginPath(); ctx.ellipse(-7, 14, 3.5, 5, 0, 0, Math.PI * 2);
  ctx.fillStyle = "#dbe6f5"; ctx.fill(); ctx.stroke();
  ctx.strokeStyle = "rgba(120,52,52,0.55)"; ctx.lineWidth = 2.4;
  // angry eyes
  ctx.fillStyle = "#fff";
  ctx.beginPath(); ctx.ellipse(14, 19, 6.4, 6, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.ellipse(30, 19, 6.4, 6, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.fillStyle = "#2b1b22";
  ctx.beginPath(); ctx.arc(15.5, 21, 2.8, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(28.5, 21, 2.8, 0, Math.PI * 2); ctx.fill();
  // brows
  ctx.strokeStyle = "#7a2723";
  ctx.lineWidth = 2.6;
  ctx.beginPath(); ctx.moveTo(8, 11.5); ctx.lineTo(18, 14.5); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(36, 11.5); ctx.lineTo(26, 14.5); ctx.stroke();
  // frown
  ctx.lineWidth = 2.2;
  ctx.beginPath(); ctx.arc(22, 34, 5, Math.PI * 1.2, Math.PI * 1.8); ctx.stroke();
  ctx.restore();
}

/* --- golden star collectible with tiny face --- */
function paintStar(ctx: CanvasRenderingContext2D, size: number) {
  const r = size / 2;
  ctx.save();
  ctx.translate(r, r);
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const rad = i % 2 === 0 ? r * 0.95 : r * 0.45;
    const a = (i * Math.PI) / 5 - Math.PI / 2;
    ctx[i === 0 ? "moveTo" : "lineTo"](Math.cos(a) * rad, Math.sin(a) * rad);
  }
  ctx.closePath();
  const g = ctx.createLinearGradient(0, -r, 0, r);
  g.addColorStop(0, "#ffe98a");
  g.addColorStop(1, "#ffb93c");
  ctx.fillStyle = g;
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = "rgba(176,110,20,0.65)";
  ctx.stroke();
  // face
  ctx.fillStyle = "#8a5a10";
  ctx.beginPath(); ctx.arc(-r * 0.22, -r * 0.05, r * 0.09, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(r * 0.22, -r * 0.05, r * 0.09, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = "#8a5a10";
  ctx.lineWidth = 1.6;
  ctx.beginPath(); ctx.arc(0, r * 0.08, r * 0.2, Math.PI * 0.2, Math.PI * 0.8); ctx.stroke();
  // glint
  ctx.fillStyle = "rgba(255,255,255,0.85)";
  ctx.beginPath(); ctx.arc(-r * 0.4, -r * 0.42, r * 0.13, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}

/* --- baby bottle (pipe + power-up share the look) --- */
function paintBottle(ctx: CanvasRenderingContext2D, w: number, h: number, top: boolean) {
  ctx.save();
  const bw = w * 0.72;
  const x = (w - bw) / 2;
  // body
  ctx.fillStyle = "#fffdf6";
  roundRect(ctx, x, top ? 14 : 0, bw, top ? h - 14 : h + 6, top ? 9 : 3);
  ctx.fill();
  ctx.lineWidth = 2.2;
  ctx.strokeStyle = "rgba(90,130,190,0.5)";
  ctx.stroke();
  // milk
  ctx.fillStyle = "rgba(255,244,214,0.9)";
  roundRect(ctx, x + 3, top ? 22 : 6, bw - 6, top ? h - 28 : h - 6, 6);
  ctx.fill();
  // heart label
  ctx.fillStyle = "#ff8fa8";
  const hy = h * 0.55;
  ctx.save();
  ctx.translate(w / 2, hy);
  const hr = w * 0.12;
  ctx.beginPath();
  ctx.moveTo(0, hr * 0.8);
  ctx.bezierCurveTo(-hr * 1.3, -hr * 0.2, -hr * 0.5, -hr * 1.2, 0, -hr * 0.4);
  ctx.bezierCurveTo(hr * 0.5, -hr * 1.2, hr * 1.3, -hr * 0.2, 0, hr * 0.8);
  ctx.fill();
  ctx.restore();
  if (top) {
    // blue ring + nipple
    ctx.fillStyle = "#7fb8ef";
    roundRect(ctx, x - 2, 6, bw + 4, 10, 5);
    ctx.fill();
    ctx.strokeStyle = "rgba(70,110,170,0.6)";
    ctx.stroke();
    ctx.fillStyle = "#f7d9a8";
    roundRect(ctx, w / 2 - w * 0.12, -2, w * 0.24, 10, 6);
    ctx.fill();
    ctx.strokeStyle = "rgba(160,110,50,0.5)";
    ctx.stroke();
  }
  ctx.restore();
}

/* --- the crib (finish line) --- */
function paintCrib(ctx: CanvasRenderingContext2D, w: number, h: number) {
  ctx.save();
  ctx.lineWidth = 2.6;
  ctx.strokeStyle = "rgba(120,80,60,0.5)";
  // mattress & blanket
  ctx.fillStyle = "#ffffff";
  roundRect(ctx, w * 0.12, h * 0.34, w * 0.76, h * 0.2, 10);
  ctx.fill(); ctx.stroke();
  ctx.fillStyle = "#a8e6cf";
  roundRect(ctx, w * 0.12, h * 0.3, w * 0.44, h * 0.24, 10);
  ctx.fill(); ctx.stroke();
  // pillow
  ctx.fillStyle = "#ffd9e8";
  roundRect(ctx, w * 0.6, h * 0.26, w * 0.26, h * 0.14, 9);
  ctx.fill(); ctx.stroke();
  // rails
  ctx.fillStyle = "#f7ead2";
  roundRect(ctx, w * 0.04, h * 0.16, w * 0.1, h * 0.62, 6);
  ctx.fill(); ctx.stroke();
  roundRect(ctx, w * 0.86, h * 0.16, w * 0.1, h * 0.62, 6);
  ctx.fill(); ctx.stroke();
  // bars
  ctx.fillStyle = "#f0e0c4";
  for (let i = 0; i < 5; i++) {
    const bx = w * 0.2 + i * w * 0.13;
    roundRect(ctx, bx, h * 0.42, w * 0.055, h * 0.36, 4);
    ctx.fill(); ctx.stroke();
  }
  roundRect(ctx, w * 0.14, h * 0.4, w * 0.72, h * 0.09, 6);
  ctx.fillStyle = "#f7ead2";
  ctx.fill(); ctx.stroke();
  // legs + wheels
  ctx.beginPath(); ctx.arc(w * 0.14, h * 0.86, w * 0.05, 0, Math.PI * 2);
  ctx.fillStyle = "#8ad1b2"; ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.arc(w * 0.86, h * 0.86, w * 0.05, 0, Math.PI * 2);
  ctx.fill(); ctx.stroke();
  // mobile post + hanging stars
  ctx.strokeStyle = "rgba(120,80,60,0.55)";
  ctx.lineWidth = 3;
  ctx.beginPath(); ctx.moveTo(w * 0.3, h * 0.34); ctx.lineTo(w * 0.3, h * 0.06); ctx.lineTo(w * 0.62, h * 0.06); ctx.stroke();
  const stars: [number, number, number][] = [[0.4, 0.12, 8], [0.52, 0.2, 6], [0.62, 0.13, 7]];
  for (const [fx, fy, r] of stars) {
    ctx.beginPath(); ctx.moveTo(w * fx, h * 0.06); ctx.lineTo(w * fx, h * fy + r); ctx.stroke();
    ctx.save();
    ctx.translate(w * fx, h * fy + r);
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
      const rad = i % 2 === 0 ? r : r * 0.45;
      const a = (i * Math.PI) / 5 - Math.PI / 2;
      ctx[i === 0 ? "moveTo" : "lineTo"](Math.cos(a) * rad, Math.sin(a) * rad);
    }
    ctx.closePath();
    ctx.fillStyle = "#ffd166";
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }
  ctx.restore();
}

/* --- checkpoint bow pole --- */
function paintPole(ctx: CanvasRenderingContext2D, h: number, taken: boolean) {
  ctx.save();
  ctx.strokeStyle = "rgba(120,80,60,0.45)";
  ctx.fillStyle = taken ? "#ffb04d" : "#c7d6ea";
  roundRect(ctx, -4, 0, 8, h, 4);
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.stroke();
  // bow flag
  ctx.save();
  ctx.translate(0, 14);
  ctx.fillStyle = taken ? "#ffd166" : "#e9eff8";
  ctx.beginPath(); ctx.ellipse(-14, 0, 12, 9, -0.4, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.ellipse(14, 0, 12, 9, 0.4, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.arc(0, 0, 5, 0, Math.PI * 2);
  ctx.fillStyle = taken ? "#fff" : "#dce6f2";
  ctx.fill(); ctx.stroke();
  ctx.restore();
  ctx.restore();
}

/* --- clouds --- */
function paintCloud(ctx: CanvasRenderingContext2D, w: number, h: number) {
  ctx.fillStyle = "rgba(255,255,255,0.95)";
  ctx.beginPath();
  ctx.arc(w * 0.28, h * 0.62, h * 0.34, 0, Math.PI * 2);
  ctx.arc(w * 0.5, h * 0.42, h * 0.42, 0, Math.PI * 2);
  ctx.arc(w * 0.74, h * 0.6, h * 0.32, 0, Math.PI * 2);
  ctx.arc(w * 0.5, h * 0.68, h * 0.3, 0, Math.PI * 2);
  ctx.fill();
}

/* ============================================================
   ENGINE
   ============================================================ */

const PRS = 3; // prerender resolution multiplier

async function makeSprite(w: number, h: number, painter: (ctx: CanvasRenderingContext2D) => void) {
  const c = document.createElement("canvas");
  c.width = w * PRS;
  c.height = h * PRS;
  const ctx = c.getContext("2d")!;
  ctx.scale(PRS, PRS);
  painter(ctx);
  return c;
}

interface Particle {
  x: number; y: number; vx: number; vy: number;
  life: number; max: number;
  size: number; color: string;
  kind: "dot" | "star" | "chip" | "text" | "confetti";
  text?: string; rot?: number; vr?: number;
}

export class Engine {
  status: GameStatus = "menu";
  private ctx: CanvasRenderingContext2D;
  private canvas: HTMLCanvasElement;
  private raf = 0;
  private last = 0;
  private time = 0;
  dpr = 1;
  viewW = 0;
  viewH = 0;

  level: LevelData = buildLevel();

  // player
  px = 0; py = 0; pvx = 0; pvy = 0;
  pw = 34; ph = 46;
  big = false;
  facing = 1;
  grounded = false;
  coyote = 0; jumpBuf = 0;
  landT = 0; invuln = 0;
  runAnimT = 0; blinkT = 2; blinkOn = false;

  // camera
  camX = 0; camY = 0;

  // input
  keys = { left: false, right: false, jump: false };
  touch = { left: false, right: false, jump: false };
  paused = false;

  // stats
  score = 0; stars = 0; lives = 3;
  respawnX = 0;

  // world entities
  private coinsTaken = new Set<number>();
  private enemies: { x: number; y: number; vx: number; dead: boolean; deadT: number; frame: number; animT: number }[] = [];
  private items: { x: number; y: number; vx: number; active: boolean; riseT: number; got: boolean }[] = [];
  private bumps: { tx: number; ty: number; t: number }[] = [];
  private particles: Particle[] = [];
  private stateT = 0; // timer for dead/winanim states

  onHud: (h: HudState) => void = () => {};
  onStatus: (s: GameStatus) => void = () => {};
  onFx: ((kind: string) => void) | null = null;

  // sprites
  private spr: Record<string, HTMLCanvasElement> = {};
  private ready = false;
  private destroyed = false;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d")!;
    this.px = this.level.startX;
    this.py = this.level.startY;
    this.respawnX = this.level.startX;
    this.spawnEnemies();
    this.resize();
    void this.buildSprites();
    this.bindKeys();
    this.last = performance.now();
    this.loop = this.loop.bind(this);
    this.raf = requestAnimationFrame(this.loop);
  }

  get worldH() { return ROWS * TILE; }
  get worldW() { return this.level.cols * TILE; }
  progress() { return Math.max(0, Math.min(1, this.px / this.level.finishX)); }

  /* ---------------- sprites ---------------- */
  private async buildSprites() {
    const frames: ["stand" | "run0" | "run1" | "jump", string][] = [
      ["stand", "stand"], ["run0", "run0"], ["run1", "run1"], ["jump", "jump"],
    ];
    for (const [f, name] of frames) {
      this.spr["baby_" + name] = await makeSprite(160, 152, (c) => paintBaby(c, 152, { frame: f, blink: false }));
      this.spr["baby_" + name + "_b"] = await makeSprite(160, 152, (c) => paintBaby(c, 152, { frame: f, blink: true }));
    }
    this.spr.enemy0 = await makeSprite(48, 44, (c) => paintToyEnemy(c, 44, 0, false));
    this.spr.enemy1 = await makeSprite(48, 44, (c) => paintToyEnemy(c, 44, 1, false));
    this.spr.enemyDead = await makeSprite(48, 44, (c) => paintToyEnemy(c, 44, 0, true));
    this.spr.star = await makeSprite(30, 30, (c) => paintStar(c, 28));
    this.spr.pipeTop = await makeSprite(TILE, TILE, (c) => paintBottle(c, TILE, TILE, true));
    this.spr.pipeBody = await makeSprite(TILE, TILE, (c) => paintBottle(c, TILE, TILE, false));
    this.spr.bottleItem = await makeSprite(34, 40, (c) => paintBottle(c, 34, 40, true));
    this.spr.crib = await makeSprite(190, 200, (c) => paintCrib(c, 190, 200));
    this.spr.pole = await makeSprite(40, 190, (c) => paintPole(c, 186, false));
    this.spr.poleOn = await makeSprite(40, 190, (c) => paintPole(c, 186, true));
    this.spr.groundTop = await makeSprite(TILE, TILE, (c) => this.paintGroundTop(c));
    this.spr.groundFill = await makeSprite(TILE, TILE, (c) => this.paintGroundFill(c));
    this.spr.brick = await makeSprite(TILE, TILE, (c) => this.paintBrick(c));
    this.spr.question = await makeSprite(TILE, TILE, (c) => this.paintQuestion(c));
    this.spr.used = await makeSprite(TILE, TILE, (c) => this.paintUsed(c));
    this.spr.plank = await makeSprite(TILE, TILE, (c) => this.paintPlank(c));
    this.spr.cloud = await makeSprite(150, 76, (c) => paintCloud(c, 150, 76));
    this.ready = true;
  }

  private paintGroundTop(c: CanvasRenderingContext2D) {
    c.fillStyle = "#f4dfc0";
    c.fillRect(0, 0, TILE, TILE);
    c.fillStyle = "#a5e8c0";
    c.fillRect(0, 0, TILE, 15);
    c.beginPath();
    for (let x = 8; x < TILE; x += 16) c.arc(x, 15, 6, 0, Math.PI);
    c.fill();
    c.fillStyle = "#cdf3de";
    c.fillRect(0, 0, TILE, 4);
    c.fillStyle = "rgba(190,140,90,0.35)";
    c.beginPath(); c.arc(12, 34, 2.4, 0, Math.PI * 2); c.arc(34, 26, 2, 0, Math.PI * 2); c.arc(26, 42, 2.6, 0, Math.PI * 2); c.fill();
  }
  private paintGroundFill(c: CanvasRenderingContext2D) {
    c.fillStyle = "#f4dfc0";
    c.fillRect(0, 0, TILE, TILE);
    c.fillStyle = "rgba(190,140,90,0.35)";
    c.beginPath(); c.arc(14, 12, 2.4, 0, Math.PI * 2); c.arc(34, 30, 2.2, 0, Math.PI * 2); c.arc(20, 40, 2.6, 0, Math.PI * 2); c.fill();
  }
  private paintBrick(c: CanvasRenderingContext2D) {
    c.fillStyle = "#ffb98a";
    roundRect(c, 1, 1, TILE - 2, TILE - 2, 7);
    c.fill();
    c.strokeStyle = "rgba(140,80,40,0.35)";
    c.lineWidth = 2;
    c.stroke();
    c.strokeStyle = "rgba(255,255,255,0.55)";
    c.beginPath(); c.moveTo(2, TILE / 2); c.lineTo(TILE - 2, TILE / 2); c.stroke();
    c.beginPath(); c.moveTo(TILE / 2, 2); c.lineTo(TILE / 2, TILE / 2); c.moveTo(TILE * 0.28, TILE / 2); c.lineTo(TILE * 0.28, TILE - 2); c.moveTo(TILE * 0.74, TILE / 2); c.lineTo(TILE * 0.74, TILE - 2); c.stroke();
    c.fillStyle = "rgba(255,255,255,0.4)";
    roundRect(c, 4, 4, TILE - 8, 8, 4); c.fill();
  }
  private paintQuestion(c: CanvasRenderingContext2D) {
    const g = c.createLinearGradient(0, 0, 0, TILE);
    g.addColorStop(0, "#ffd97a");
    g.addColorStop(1, "#ffb347");
    c.fillStyle = g;
    roundRect(c, 1, 1, TILE - 2, TILE - 2, 8);
    c.fill();
    c.strokeStyle = "rgba(150,90,20,0.4)";
    c.lineWidth = 2.4;
    c.stroke();
    c.fillStyle = "rgba(150,90,20,0.5)";
    for (const [px, py] of [[7, 7], [TILE - 7, 7], [7, TILE - 7], [TILE - 7, TILE - 7]]) {
      c.beginPath(); c.arc(px, py, 2.4, 0, Math.PI * 2); c.fill();
    }
    c.font = `900 ${TILE * 0.62}px Vazirmatn, sans-serif`;
    c.textAlign = "center";
    c.textBaseline = "middle";
    c.fillStyle = "#fff";
    c.strokeStyle = "rgba(150,90,20,0.5)";
    c.lineWidth = 5;
    c.strokeText("؟", TILE / 2, TILE / 2 + 3);
    c.fillText("؟", TILE / 2, TILE / 2 + 3);
  }
  private paintUsed(c: CanvasRenderingContext2D) {
    c.fillStyle = "#c9a06a";
    roundRect(c, 1, 1, TILE - 2, TILE - 2, 8);
    c.fill();
    c.strokeStyle = "rgba(110,70,30,0.45)";
    c.lineWidth = 2.4;
    c.stroke();
    c.fillStyle = "rgba(110,70,30,0.35)";
    c.beginPath(); c.arc(TILE / 2, TILE / 2, 4, 0, Math.PI * 2); c.fill();
  }
  private paintPlank(c: CanvasRenderingContext2D) {
    const g = c.createLinearGradient(0, 0, 0, TILE);
    g.addColorStop(0, "#bfe0ff");
    g.addColorStop(1, "#8fbdf5");
    c.fillStyle = g;
    roundRect(c, 0, 6, TILE, TILE - 14, 10);
    c.fill();
    c.strokeStyle = "rgba(60,110,180,0.4)";
    c.lineWidth = 2.2;
    c.stroke();
    c.fillStyle = "rgba(255,255,255,0.6)";
    roundRect(c, 5, 9, TILE - 10, 6, 3);
    c.fill();
  }

  /* ---------------- enemies & items ---------------- */
  private spawnEnemies() {
    this.enemies = this.level.enemies.map((e) => ({
      x: e.tx * TILE + 4,
      y: e.ty * TILE + TILE - 38,
      vx: -55,
      dead: false,
      deadT: 0,
      frame: 0,
      animT: Math.random(),
    }));
  }

  private emitHud() {
    this.onHud({ score: this.score, stars: this.stars, lives: this.lives, big: this.big });
  }

  private setStatus(s: GameStatus) {
    this.status = s;
    this.onStatus(s);
  }

  /* ---------------- game flow ---------------- */
  start() {
    sfx.init();
    this.level = buildLevel();
    this.spawnEnemies();
    this.coinsTaken.clear();
    this.items = [];
    this.bumps = [];
    this.particles = [];
    this.score = 0; this.stars = 0; this.lives = 3;
    this.big = false;
    this.respawnX = this.level.startX;
    this.resetPlayer(this.level.startX);
    this.setStatus("play");
    this.emitHud();
  }

  private resetPlayer(x: number) {
    this.px = x;
    this.py = (GROUND_ROW - 2) * TILE;
    this.pvx = 0; this.pvy = 0;
    this.facing = 1;
    this.invuln = 2;
    this.camX = Math.max(0, this.px - this.viewW * 0.35);
  }

  pauseToggle() {
    if (this.status === "play") this.paused = !this.paused;
  }

  /* ---------------- input ---------------- */
  private keyHandler = (e: KeyboardEvent) => {
    const k = e.key;
    if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", " "].includes(k)) e.preventDefault();
    const v = e.type === "keydown";
    if (k === "ArrowLeft" || k === "a" || k === "A") this.keys.left = v;
    if (k === "ArrowRight" || k === "d" || k === "D") this.keys.right = v;
    if (k === "ArrowUp" || k === "w" || k === "W" || k === " ") this.keys.jump = v;
    if ((k === "p" || k === "P" || k === "Escape") && v) this.pauseToggle();
    if (k === "Enter" && v && (this.status === "over" || this.status === "win")) this.start();
  };
  private bindKeys() {
    window.addEventListener("keydown", this.keyHandler);
    window.addEventListener("keyup", this.keyHandler);
    window.addEventListener("blur", () => { this.keys = { left: false, right: false, jump: false }; });
  }

  resize() {
    const rect = this.canvas.parentElement!.getBoundingClientRect();
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.viewW = rect.width;
    this.viewH = rect.height;
    this.canvas.width = Math.round(rect.width * this.dpr);
    this.canvas.height = Math.round(rect.height * this.dpr);
    this.canvas.style.width = rect.width + "px";
    this.canvas.style.height = rect.height + "px";
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener("keydown", this.keyHandler);
    window.removeEventListener("keyup", this.keyHandler);
    this.destroyed = true;
  }

  /* ---------------- solids ---------------- */
  private solidAt(tx: number, ty: number): number {
    if (tx < 0 || tx >= this.level.cols) return T.GROUND;
    if (ty < 0 || ty >= this.level.rows) return T.EMPTY;
    return this.level.grid[ty * this.level.cols + tx];
  }
  private isSolid(tx: number, ty: number) { return this.solidAt(tx, ty) !== T.EMPTY; }

  /* ---------------- main loop ---------------- */
  private loop(now: number) {
    if (this.destroyed) return;
    const dt = Math.min((now - this.last) / 1000, 1 / 30);
    this.last = now;
    this.time += dt;
    if (!this.paused) this.update(dt);
    this.render();
    this.raf = requestAnimationFrame(this.loop);
  }

  /* ---------------- update ---------------- */
  private update(dt: number) {
    const L = this.level;
    const jump = this.keys.jump || this.touch.jump;
    const left = this.keys.left || this.touch.left;
    const right = this.keys.right || this.touch.right;

    // blink
    this.blinkT -= dt;
    if (this.blinkT <= 0) {
      this.blinkOn = !this.blinkOn;
      this.blinkT = this.blinkOn ? 0.12 : 2.2 + Math.random() * 2.2;
    }

    if (this.status === "play") {
      const ACCEL = 2400, MAX = 320, FRIC = 2000;
      const G = 2400, JUMP_V = 690, JUMP_HOLD_G = 1150;

      if (left) { this.pvx -= ACCEL * dt; this.facing = -1; }
      else if (right) { this.pvx += ACCEL * dt; this.facing = 1; }
      else if (this.grounded) {
        const s = Math.sign(this.pvx);
        this.pvx -= s * Math.min(Math.abs(this.pvx), FRIC * dt);
      } else this.pvx *= 1 - 0.35 * dt;
      this.pvx = Math.max(-MAX, Math.min(MAX, this.pvx));

      const g = this.pvy < 0 && jump ? JUMP_HOLD_G : G;
      this.pvy = Math.min(this.pvy + g * dt, 980);

      this.coyote -= dt;
      this.jumpBuf -= dt;
      if (jump && !this.prevJump) this.jumpBuf = 0.13;
      if (this.grounded) this.coyote = 0.1;
      if (this.coyote > 0 && this.jumpBuf > 0) {
        this.pvy = -JUMP_V * (this.big ? 0.97 : 1);
        this.grounded = false;
        this.coyote = 0; this.jumpBuf = 0;
        sfx.jump(this.big);
        this.burst(this.px + this.pw / 2, this.py + this.ph, 5, "#ffffff", "dot", 90);
      }

      // X move & collide
      this.px += this.pvx * dt;
      this.collideAxis(true);
      // Y move & collide
      const wasGrounded = this.grounded;
      this.grounded = false;
      const prevBottom = this.py + this.ph;
      this.py += this.pvy * dt;
      this.collideAxis(false, prevBottom);
      if (!wasGrounded && this.grounded) {
        this.landT = 0.16;
        if (this.pvy >= 0) this.burst(this.px + this.pw / 2, this.py + this.ph, 4, "#e8d9c0", "dot", 60);
      }
      this.landT = Math.max(0, this.landT - dt);
      this.ph = this.big ? 58 : 46;

      // run dust
      if (this.grounded && Math.abs(this.pvx) > 140) {
        this.runAnimT += dt;
        if (this.runAnimT > 0.16) {
          this.runAnimT = 0;
          this.burst(this.px + this.pw / 2 - this.facing * 12, this.py + this.ph - 2, 1, "rgba(255,255,255,0.9)", "dot", 40);
        }
      }

      // world x clamp
      this.px = Math.max(8, Math.min(this.worldW - this.pw - 8, this.px));

      // checkpoints
      for (const cp of L.checkpoints) {
        if (!cp.taken && this.px > cp.x) {
          cp.taken = true;
          this.respawnX = cp.x + TILE;
          sfx.checkpoint();
          this.burst(cp.x, this.py, 10, "#ffd166", "star", 120);
          this.popup(cp.x, this.py - 30, "تپل شد!");
        }
      }

      // coins
      L.coins.forEach((c, i) => {
        if (this.coinsTaken.has(i)) return;
        const cx = c.tx * TILE + TILE / 2, cy = c.ty * TILE + TILE / 2;
        if (overlap(this.px, this.py, this.pw, this.ph, cx - 14, cy - 14, 28, 28)) {
          this.coinsTaken.add(i);
          this.stars++;
          this.score += 100;
          sfx.coin();
          this.burst(cx, cy, 6, "#ffd166", "star", 100);
          this.emitHud();
        }
      });

      // items
      for (const it of this.items) {
        if (it.got) continue;
        if (!it.active) {
          it.riseT += dt;
          it.y -= 42 * dt;
          if (it.riseT > 0.75) it.active = true;
          continue;
        }
        const wasBottom = it.y + 34;
        it.x += it.vx * dt;
        if (this.isSolid(Math.floor((it.x + (it.vx > 0 ? 31 : -1)) / TILE), Math.floor((it.y + 20) / TILE))) it.vx *= -1;
        // gravity
        (it as any).vy = ((it as any).vy ?? 0) + 2000 * dt;
        it.y += (it as any).vy * dt;
        const tx = Math.floor((it.x + 15) / TILE);
        const ty = Math.floor((it.y + 34) / TILE);
        const tyPrev = Math.floor(wasBottom / TILE);
        if (this.isSolid(tx, ty) && ty >= tyPrev) {
          it.y = ty * TILE - 34;
          (it as any).vy = 0;
        }
        if (it.y > this.worldH + 100) { it.got = true; continue; }
        if (overlap(this.px, this.py, this.pw, this.ph, it.x, it.y, 30, 34)) {
          it.got = true;
          this.score += 1000;
          this.popup(it.x, it.y - 20, "+" + faNum(1000));
          if (!this.big) {
            this.big = true;
            this.py -= 12;
            sfx.power();
          } else sfx.coin();
          this.burst(it.x + 15, it.y + 17, 12, "#ffd166", "star", 140);
          this.emitHud();
        }
      }
      this.items = this.items.filter((i) => !i.got);

      // enemies
      for (const e of this.enemies) {
        if (e.dead) { e.deadT += dt; continue; }
        e.animT += dt;
        if (e.animT > 0.18) { e.animT = 0; e.frame = 1 - e.frame; }
        e.x += e.vx * dt;
        // wall flip
        const aheadTx = Math.floor((e.x + (e.vx > 0 ? 40 : -2)) / TILE);
        const midTy = Math.floor((e.y + 20) / TILE);
        if (this.isSolid(aheadTx, midTy)) e.vx *= -1;
        // edge flip
        const belowTy = Math.floor((e.y + 42) / TILE);
        if (!this.isSolid(aheadTx, belowTy) && this.isSolid(Math.floor((e.x + 19) / TILE), belowTy)) e.vx *= -1;

        if (this.invuln <= 0 && overlap(this.px + 3, this.py + 4, this.pw - 6, this.ph - 4, e.x, e.y, 38, 36)) {
          const stomped = this.pvy > 80 && this.py + this.ph - e.y < 22;
          if (stomped) {
            e.dead = true;
            e.deadT = 0;
            this.pvy = -420;
            this.score += 200;
            sfx.stomp();
            this.burst(e.x + 19, e.y + 10, 8, "#ffb3a7", "chip", 130);
            this.popup(e.x, e.y - 24, "+" + faNum(200));
            this.emitHud();
          } else this.hurt(e.x + 19 < this.px + this.pw / 2 ? 1 : -1);
        }
      }
      this.enemies = this.enemies.filter((e) => !e.dead || e.deadT < 0.6);

      // finish!
      if (this.px + this.pw > L.finishX + 4) {
        this.setStatus("winanim");
        this.stateT = 0;
        this.score += 2000;
        sfx.win();
        this.emitHud();
      }

      // fell into pit
      if (this.py > this.worldH + 60) this.die();

      this.invuln = Math.max(0, this.invuln - dt);
    }

    if (this.status === "winanim") {
      this.stateT += dt;
      // stroll into the crib
      this.pvx = 120;
      this.px += this.pvx * dt;
      this.pvy = Math.min(this.pvy + 2400 * dt, 980);
      const pb = this.py + this.ph;
      this.py += this.pvy * dt;
      this.collideAxis(false, pb);
      const stopX = L.finishX + 58;
      if (this.px >= stopX) { this.px = stopX; this.pvx = 0; }
      if (Math.floor(this.stateT * 3.3) !== Math.floor((this.stateT - dt) * 3.3)) {
        this.confetti(this.px + this.pw / 2 + (Math.random() * 240 - 120), this.py - 80 - Math.random() * 60);
      }
      if (this.stateT > 2.2) {
        this.setStatus("win");
        const best = Number(localStorage.getItem("nini-best") || 0);
        if (this.score > best) localStorage.setItem("nini-best", String(this.score));
      }
      // blink fast with joy
    }

    if (this.status === "dead") {
      this.stateT += dt;
      this.pvy += 2200 * dt;
      this.py += this.pvy * dt;
      if (this.stateT > 1.5) {
        if (this.lives > 0) {
          this.resetPlayer(this.respawnX);
          this.setStatus("play");
        } else {
          this.setStatus("over");
          const best = Number(localStorage.getItem("nini-best") || 0);
          if (this.score > best) localStorage.setItem("nini-best", String(this.score));
        }
      }
    }

    // menu attract: gentle drift
    if (this.status === "menu") {
      this.camX = (Math.sin(this.time * 0.12) * 0.5 + 0.5) * 300;
    } else {
      const target = this.px + this.pw / 2 - this.viewW * 0.4;
      this.camX += (target - this.camX) * (1 - Math.exp(-dt * 7));
      this.camX = Math.max(0, Math.min(this.worldW - this.viewW, this.camX));
    }
    this.camY = this.worldH - this.viewH - 26;

    // bumps
    for (const b of this.bumps) b.t += dt;
    this.bumps = this.bumps.filter((b) => b.t < 0.32);

    // particles
    for (const p of this.particles) {
      p.life -= dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      if (p.kind !== "confetti" && p.kind !== "text") p.vy += 500 * dt;
      if (p.kind === "confetti") { p.vy = 190; p.vx *= 1 - 1.4 * dt; if (p.rot !== undefined && p.vr) p.rot += p.vr * dt; }
      if (p.kind === "text") p.vy = -55;
    }
    this.particles = this.particles.filter((p) => p.life > 0);

    this.prevJump = jump;
  }
  private prevJump = false;

  /* ---------------- collision ---------------- */
  private collideAxis(xAxis: boolean, prevBottom = 0) {
    const x0 = Math.floor(this.px / TILE), x1 = Math.floor((this.px + this.pw) / TILE);
    const y0 = Math.floor(this.py / TILE), y1 = Math.floor((this.py + this.ph) / TILE);
    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        if (!this.isSolid(tx, ty)) continue;
        const bx = tx * TILE, by = ty * TILE;
        if (!overlap(this.px, this.py, this.pw, this.ph, bx, by, TILE, TILE)) continue;
        if (xAxis) {
          if (this.pvx > 0) this.px = bx - this.pw;
          else if (this.pvx < 0) this.px = bx + TILE;
          else this.px = bx + TILE < this.px + this.pw / 2 ? bx + TILE : bx - this.pw;
          this.pvx = 0;
        } else {
          if (this.pvy > 0 && prevBottom <= by + 14) {
            this.py = by - this.ph;
            this.pvy = 0;
            this.grounded = true;
          } else if (this.pvy < 0) {
            this.py = by + TILE;
            this.pvy = 40;
            this.bumpBlock(tx, ty);
          }
        }
      }
    }
  }

  private bumpBlock(tx: number, ty: number) {
    const id = this.solidAt(tx, ty);
    const idx = ty * this.level.cols + tx;
    if (id === T.QUESTION) {
      this.level.grid[idx] = T.USED;
      this.bumps.push({ tx, ty, t: 0 });
      // bottle pops out!
      this.items.push({
        x: tx * TILE + 8,
        y: ty * TILE - 30,
        vx: 105,
        active: false,
        riseT: 0,
        got: false,
      });
      sfx.sprout();
    } else if (id === T.BRICK) {
      if (this.big) {
        this.level.grid[idx] = T.EMPTY;
        this.score += 50;
        sfx.brick();
        sfx.bump();
        for (let i = 0; i < 8; i++) {
          this.particles.push({
            x: tx * TILE + TILE / 2, y: ty * TILE + TILE / 2,
            vx: (Math.random() - 0.5) * 260, vy: -Math.random() * 260 - 60,
            life: 0.7, max: 0.7, size: 7 + Math.random() * 5,
            color: "#ffb98a", kind: "chip",
          });
        }
        this.emitHud();
      } else {
        this.bumps.push({ tx, ty, t: 0 });
        sfx.bump();
      }
    } else sfx.bump();
  }

  /* ---------------- damage & death ---------------- */
  private hurt(dir: number) {
    if (this.big) {
      this.big = false;
      this.invuln = 1.8;
      this.pvx = dir * 240;
      this.pvy = -320;
      sfx.hurt();
      this.burst(this.px + this.pw / 2, this.py + this.ph / 2, 10, "#ffd9e8", "dot", 130);
      this.emitHud();
    } else this.die();
  }

  private die() {
    if (this.status !== "play") return;
    this.lives--;
    this.big = false;
    this.emitHud();
    this.setStatus("dead");
    this.stateT = 0;
    this.pvy = -560;
    sfx.die();
  }

  /* ---------------- particles ---------------- */
  private burst(x: number, y: number, n: number, color: string, kind: Particle["kind"], speed: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const v = speed * (0.4 + Math.random() * 0.8);
      this.particles.push({
        x, y,
        vx: Math.cos(a) * v, vy: Math.sin(a) * v - 60,
        life: 0.5 + Math.random() * 0.35, max: 0.85,
        size: 3 + Math.random() * 4, color, kind,
      });
    }
    if (this.particles.length > 320) this.particles.splice(0, this.particles.length - 320);
  }
  private popup(x: number, y: number, text: string) {
    this.particles.push({
      x, y, vx: 0, vy: -55, life: 1, max: 1, size: 17, color: "#ff8a3d", kind: "text", text,
    });
  }
  private confetti(x: number, y: number) {
    const colors = ["#ff6b8a", "#ffd166", "#6bd6ff", "#9de88f", "#c79bff", "#ff9d5c"];
    for (let i = 0; i < 14; i++) {
      this.particles.push({
        x: x + (Math.random() - 0.5) * 60, y: y + (Math.random() - 0.5) * 20,
        vx: (Math.random() - 0.5) * 160, vy: -Math.random() * 120,
        life: 2.2 + Math.random(), max: 3,
        size: 5 + Math.random() * 5,
        color: colors[(Math.random() * colors.length) | 0],
        kind: "confetti",
        rot: Math.random() * Math.PI, vr: (Math.random() - 0.5) * 14,
      });
    }
  }
  /* ============================================================
     RENDER
     ============================================================ */
  private render() {
    const ctx = this.ctx;
    const { dpr, viewW, viewH } = this;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // sky
    const sky = ctx.createLinearGradient(0, 0, 0, viewH);
    sky.addColorStop(0, "#8ec9ff");
    sky.addColorStop(0.55, "#c7e8ff");
    sky.addColorStop(0.8, "#f3ecdc");
    sky.addColorStop(1, "#f6e7cf");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, viewW, viewH);

    // sun
    const sunX = viewW * 0.82, sunY = viewH * 0.16;
    const sg = ctx.createRadialGradient(sunX, sunY, 10, sunX, sunY, 110);
    sg.addColorStop(0, "rgba(255,236,170,0.95)");
    sg.addColorStop(0.35, "rgba(255,224,150,0.5)");
    sg.addColorStop(1, "rgba(255,224,150,0)");
    ctx.fillStyle = sg;
    ctx.fillRect(sunX - 120, sunY - 120, 240, 240);
    ctx.fillStyle = "#ffe9a8";
    ctx.beginPath(); ctx.arc(sunX, sunY, 34, 0, Math.PI * 2); ctx.fill();

    if (!this.ready) return;

    // clouds (two parallax layers)
    this.drawCloudLayer(0.22, viewH * 0.12, 1.05, 560);
    this.drawCloudLayer(0.4, viewH * 0.3, 0.72, 430);

    // hills
    this.drawHills(0.5, viewH - 90, "#bfe8d0", 220, 160);
    this.drawHills(0.72, viewH - 52, "#a2dcb8", 170, 110);

    ctx.save();
    ctx.translate(-Math.round(this.camX), -Math.round(this.camY));

    this.drawTiles(ctx);
    this.drawCheckpoints(ctx);
    this.drawCrib(ctx);
    this.drawCoins(ctx);
    this.drawItems(ctx);
    this.drawEnemies(ctx);

    // butterflies
    this.drawButterflies(ctx);

    if (this.status !== "menu") this.drawPlayer(ctx);
    else this.drawMenuBaby(ctx);

    // particles
    for (const p of this.particles) this.drawParticle(ctx, p);

    ctx.restore();

    // soft top light
    const vg = ctx.createLinearGradient(0, 0, 0, viewH * 0.25);
    vg.addColorStop(0, "rgba(255,255,255,0.25)");
    vg.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, viewW, viewH * 0.25);
  }

  private drawCloudLayer(par: number, baseY: number, scale: number, spacing: number) {
    const ctx = this.ctx;
    const off = this.camX * par;
    const start = Math.floor((off - 200) / spacing);
    const count = Math.ceil(this.viewW / spacing) + 3;
    for (let i = start; i < start + count; i++) {
      const wx = i * spacing - off;
      const drift = Math.sin(this.time * 0.25 + i * 2.1) * 8;
      const wy = baseY + Math.sin(i * 1.7) * viewH_safe(this.viewH) * 0.05 + drift;
      ctx.globalAlpha = 0.85;
      ctx.drawImage(this.spr.cloud, wx, wy, 150 * scale, 76 * scale);
      ctx.globalAlpha = 1;
    }
  }

  private drawHills(par: number, baseY: number, color: string, r: number, spacing: number) {
    const ctx = this.ctx;
    const off = this.camX * par;
    ctx.fillStyle = color;
    const start = Math.floor((off - r) / spacing);
    const count = Math.ceil(this.viewW / spacing) + 3;
    ctx.beginPath();
    for (let i = start; i < start + count; i++) {
      const x = i * spacing - off;
      ctx.moveTo(x + r, baseY + 400);
      ctx.arc(x + r, baseY, r, Math.PI, 0);
    }
    ctx.fill();
  }

  private drawTiles(ctx: CanvasRenderingContext2D) {
    const x0 = Math.max(0, Math.floor(this.camX / TILE) - 1);
    const x1 = Math.min(this.level.cols - 1, Math.floor((this.camX + this.viewW) / TILE) + 1);
    for (let ty = 0; ty < this.level.rows; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        const id = this.level.grid[ty * this.level.cols + tx];
        if (id === T.EMPTY) continue;
        const bump = this.bumps.find((b) => b.tx === tx && b.ty === ty);
        const oy = bump ? -Math.sin((bump.t / 0.32) * Math.PI) * 9 : 0;
        const wx = tx * TILE, wy = ty * TILE + oy;
        switch (id) {
          case T.GROUND: {
            const above = this.solidAt(tx, ty - 1);
            ctx.drawImage(above === T.EMPTY ? this.spr.groundTop : this.spr.groundFill, wx, wy);
            if (above === T.EMPTY && ty === GROUND_ROW && tx % 3 === 1) this.drawFlower(ctx, wx, wy);
            break;
          }
          case T.BRICK: ctx.drawImage(this.spr.brick, wx, wy); break;
          case T.QUESTION: {
            const pulse = Math.sin(this.time * 3 + tx) * 0.04 + 1;
            ctx.save();
            ctx.translate(wx + TILE / 2, wy + TILE / 2);
            ctx.scale(pulse, pulse);
            ctx.drawImage(this.spr.question, -TILE / 2, -TILE / 2);
            ctx.restore();
            break;
          }
          case T.USED: ctx.drawImage(this.spr.used, wx, wy); break;
          case T.PLANK: ctx.drawImage(this.spr.plank, wx, wy); break;
          case T.PIPE: {
            const above = this.solidAt(tx, ty - 1);
            ctx.drawImage(above === T.PIPE ? this.spr.pipeBody : this.spr.pipeTop, wx, wy);
            break;
          }
        }
      }
    }
  }

  private drawFlower(ctx: CanvasRenderingContext2D, wx: number, wy: number) {
    const sway = Math.sin(this.time * 2 + wx * 0.05) * 0.13;
    ctx.save();
    ctx.translate(wx + TILE / 2, wy);
    ctx.rotate(sway);
    ctx.strokeStyle = "#6fbf8f";
    ctx.lineWidth = 2.4;
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(2, -10, 0, -18); ctx.stroke();
    const cols = ["#ff8fab", "#ffd166", "#c79bff"];
    ctx.fillStyle = cols[Math.abs(Math.floor(wx / TILE)) % 3];
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2 + this.time * 0.1;
      ctx.beginPath(); ctx.ellipse(Math.cos(a) * 5, -20 + Math.sin(a) * 5, 4, 4, 0, 0, Math.PI * 2); ctx.fill();
    }
    ctx.fillStyle = "#fff4c9";
    ctx.beginPath(); ctx.arc(0, -20, 3.6, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  private drawCheckpoints(ctx: CanvasRenderingContext2D) {
    const gy = GROUND_ROW * TILE;
    for (const cp of this.level.checkpoints) {
      const s = cp.taken ? this.spr.poleOn : this.spr.pole;
      ctx.drawImage(s, cp.x - 8, gy - 186);
    }
  }

  private drawCrib(ctx: CanvasRenderingContext2D) {
    const bobY = Math.sin(this.time * 2.2) * 3;
    ctx.drawImage(this.spr.crib, this.level.finishX - 60, GROUND_ROW * TILE - 184 + bobY * 0.4, 190, 200);
    // glow beacon
    if (this.status === "play") {
      ctx.save();
      ctx.globalAlpha = 0.5 + Math.sin(this.time * 3) * 0.2;
      const g = ctx.createRadialGradient(this.level.finishX + 40, (GROUND_ROW) * TILE - 60, 10, this.level.finishX + 40, (GROUND_ROW) * TILE - 60, 90);
      g.addColorStop(0, "rgba(255,224,150,0.5)");
      g.addColorStop(1, "rgba(255,224,150,0)");
      ctx.fillStyle = g;
      ctx.fillRect(this.level.finishX - 60, (GROUND_ROW) * TILE - 150, 200, 180);
      ctx.restore();
    }
  }

  private drawCoins(ctx: CanvasRenderingContext2D) {
    this.level.coins.forEach((c, i) => {
      if (this.coinsTaken.has(i)) return;
      const cx = c.tx * TILE + TILE / 2;
      if (cx < this.camX - 40 || cx > this.camX + this.viewW + 40) return;
      const cy = c.ty * TILE + TILE / 2 + Math.sin(this.time * 2.6 + i * 0.8) * 3.5;
      const spin = Math.cos(this.time * 3 + i * 0.6);
      ctx.save();
      ctx.translate(cx, cy);
      ctx.scale(Math.max(Math.abs(spin), 0.18), 1);
      ctx.drawImage(this.spr.star, -14, -14, 28, 28);
      ctx.restore();
    });
  }

  private drawItems(ctx: CanvasRenderingContext2D) {
    for (const it of this.items) {
      if (it.got) continue;
      const wob = it.active ? Math.sin(this.time * 6) * 0.1 : 0;
      ctx.save();
      ctx.translate(it.x + 15, it.y + 17);
      ctx.rotate(wob);
      ctx.drawImage(this.spr.bottleItem, -17, -20, 34, 40);
      ctx.restore();
    }
  }

  private drawEnemies(ctx: CanvasRenderingContext2D) {
    for (const e of this.enemies) {
      if (e.x < this.camX - 60 || e.x > this.camX + this.viewW + 60) continue;
      if (e.dead) {
        const a = Math.max(0, 1 - e.deadT / 0.6);
        ctx.save();
        ctx.globalAlpha = a;
        ctx.drawImage(this.spr.enemyDead, e.x - 4, e.y, 48, 44);
        ctx.restore();
      } else {
        const spr = e.frame === 0 ? this.spr.enemy0 : this.spr.enemy1;
        ctx.save();
        ctx.translate(e.x + 19, e.y + 18);
        ctx.rotate(Math.sin(this.time * 8 + e.x * 0.1) * 0.05);
        ctx.scale(e.vx > 0 ? -1 : 1, 1);
        ctx.drawImage(spr, -24, -22, 48, 44);
        ctx.restore();
      }
    }
  }

  private drawButterflies(ctx: CanvasRenderingContext2D) {
    for (let i = 0; i < 3; i++) {
      const seed = i * 977;
      const wx = ((seed + this.time * (20 + i * 8)) % (this.worldW + 400)) - 200 + this.camX * 0.0;
      const baseX = this.camX + wx - this.camX; // world
      const x = ((baseX % this.worldW) + this.worldW) % this.worldW;
      const y = (GROUND_ROW - 2.6) * TILE + Math.sin(this.time * 1.8 + i * 2.4) * 46 + i * 24 - 60;
      if (x < this.camX - 40 || x > this.camX + this.viewW + 40) continue;
      const flap = Math.sin(this.time * 16 + i) * 0.7;
      ctx.save();
      ctx.translate(x, y);
      ctx.fillStyle = ["#ff9ec7", "#9dc9ff", "#ffc98a"][i];
      ctx.save(); ctx.rotate(-0.5 - flap * 0.5);
      ctx.beginPath(); ctx.ellipse(-5, 0, 6, 9, -0.4, 0, Math.PI * 2); ctx.fill(); ctx.restore();
      ctx.save(); ctx.rotate(0.5 + flap * 0.5);
      ctx.beginPath(); ctx.ellipse(5, 0, 6, 9, 0.4, 0, Math.PI * 2); ctx.fill(); ctx.restore();
      ctx.fillStyle = "#5b4a68";
      ctx.beginPath(); ctx.ellipse(0, 0, 1.6, 6, 0, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
    }
  }

  /* -------- the star of the show -------- */
  private drawPlayer(ctx: CanvasRenderingContext2D) {
    let frame: string;
    if (!this.grounded) frame = "jump";
    else if (Math.abs(this.pvx) > 30) frame = Math.floor(this.time * 9) % 2 === 0 ? "run0" : "run1";
    else frame = "stand";
    if (this.status === "dead") frame = "jump";
    let name = "baby_" + frame + (this.blinkOn ? "_b" : "");
    let spr = this.spr[name] || this.spr.baby_stand;

    // squash & stretch
    let sx = 1, sy = 1;
    if (!this.grounded && this.status !== "menu") { const k = Math.min(Math.abs(this.pvy) / 900, 1); sx = 1 - 0.13 * k; sy = 1 + 0.16 * k; }
    else if (this.landT > 0) { const k = this.landT / 0.16; sx = 1 + 0.18 * k; sy = 1 - 0.22 * k; }
    else if (frame.startsWith("run")) { const k = Math.sin(this.time * 18); sy = 1 + 0.035 * k; sx = 1 - 0.03 * k; }
    else { const k = Math.sin(this.time * 2.6); sy = 1 + 0.02 * k; }
    if (this.status === "winanim") { sy = 1 + Math.sin(this.time * 8) * 0.05; }

    const hMul = this.big ? 2.35 : 1.9;
    const dh = this.ph * hMul * sy;
    const dw = dh * (160 / 152) * sx;
    const feetX = this.px + this.pw / 2;
    const feetY = this.py + this.ph;

    // shadow
    if (this.grounded) {
      ctx.save();
      ctx.globalAlpha = 0.18;
      ctx.fillStyle = "#7a5b3a";
      ctx.beginPath();
      ctx.ellipse(feetX, feetY + 3, this.pw * 0.62, 5.5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    ctx.save();
    if (this.invuln > 0 && this.status === "play") {
      ctx.globalAlpha = Math.floor(this.time * 12) % 2 === 0 ? 0.45 : 0.95;
    }
    ctx.translate(feetX, feetY);
    let rot = 0;
    if (!this.grounded) rot = this.facing * Math.min(Math.abs(this.pvx) / 900, 0.16);
    else if (Math.abs(this.pvx) > 30) rot = this.facing * 0.06;
    if (this.status === "dead") rot = -0.9;
    ctx.rotate(rot);
    ctx.scale(this.facing, 1);
    ctx.drawImage(spr, -dw / 2, -dh + 4, dw, dh);
    ctx.restore();
  }

  private drawMenuBaby(ctx: CanvasRenderingContext2D) {
    const frame = Math.floor(this.time * 2.2) % 2 === 0 ? "stand" : "run0";
    const name = "baby_" + frame + (this.blinkOn ? "_b" : "");
    const spr = this.spr[name];
    const x = this.camX + this.viewW * 0.5;
    const y = GROUND_ROW * TILE;
    const bob = Math.sin(this.time * 2.4) * 6;
    const dh = 132, dw = dh * (160 / 152);
    ctx.save();
    ctx.globalAlpha = 0.16;
    ctx.fillStyle = "#7a5b3a";
    ctx.beginPath(); ctx.ellipse(x, y + 3, 34, 7, 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    ctx.drawImage(spr, x - dw / 2, y - dh + bob, dw, dh);
  }

  private drawParticle(ctx: CanvasRenderingContext2D, p: Particle) {
    const a = Math.max(0, p.life / p.max);
    ctx.save();
    if (p.kind === "text") {
      ctx.globalAlpha = Math.min(1, a * 2);
      ctx.font = `900 ${p.size}px Vazirmatn, sans-serif`;
      ctx.textAlign = "center";
      ctx.lineWidth = 4;
      ctx.strokeStyle = "#fff";
      ctx.strokeText(p.text!, p.x, p.y);
      ctx.fillStyle = p.color;
      ctx.fillText(p.text!, p.x, p.y);
    } else if (p.kind === "star") {
      ctx.globalAlpha = a;
      ctx.translate(p.x, p.y);
      ctx.rotate(this.time * 6);
      const r = p.size;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      for (let i = 0; i < 8; i++) {
        const rad = i % 2 === 0 ? r : r * 0.4;
        const ang = (i * Math.PI) / 4;
        ctx[i === 0 ? "moveTo" : "lineTo"](Math.cos(ang) * rad, Math.sin(ang) * rad);
      }
      ctx.closePath();
      ctx.fill();
    } else if (p.kind === "confetti") {
      ctx.globalAlpha = Math.min(1, a * 2.4);
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot || 0);
      ctx.fillStyle = p.color;
      ctx.fillRect(-p.size / 2, -p.size / 3, p.size, p.size * 0.66);
    } else {
      ctx.globalAlpha = a * 0.9;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * (0.5 + a * 0.5), 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }
}

function viewH_safe(v: number) { return v || 600; }
