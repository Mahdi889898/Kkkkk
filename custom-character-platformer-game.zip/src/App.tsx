import BabyGame from "./game/BabyGame";

export default function App() {
  return <BabyGame />;
}
