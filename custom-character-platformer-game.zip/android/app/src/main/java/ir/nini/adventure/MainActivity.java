package ir.nini.adventure;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
