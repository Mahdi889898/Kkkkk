# 📱 ساخت APK از بازی «ماجراجویی نی‌نی»

پروژه‌ی اندروید با **Capacitor** آماده شده است. فقط کافی است طبق یکی از روش‌های زیر جلو بروید.

---

## روش صفر — ساخت ابری با GitHub (بدون نصب هیچ‌چیز!) ☁️ ⭐

اگر روی سیستم‌ات به مشکل خوردی، این ساده‌ترین راه است:

1. یک حساب رایگان در **github.com** بساز.
2. یک ریپازیتوری جدید (Public یا Private) بساز و کل پوشه‌ی این پروژه را در آن آپلود/push کن.
3. در صفحه‌ی ریپازیتوری به تب **Actions** برو.
4. ورک‌فلوی **«ساخت APK بازی نی‌نی»** را ببینی؛ روی **Run workflow** کلیک کن.
5. بعد از چند دقیقه، پایین همان صفحه در بخش **Artifacts** فایل **nini-apk** قابل دانلود است — داخلش APK بازی است! 🎉

> گیت‌هاب سرورهای خودش را دارد، پس مشکل تحریم و دانلود Gradle هم پیش نمی‌آید.

---

## اجرای «با یک کلیک» روی سیستم خودت 🖱️

- **ویندوز:** روی فایل **`build-apk.bat`** دابل‌کلیک کن.
- **مک/لینوکس:** در ترمینال بزن: `bash build-apk.sh`

پیش‌نیاز: Node.js + Android Studio نصب باشد و **فیلترشکن روشن**.

---

## روش ۱ — با Android Studio (پیشنهادی، ساده‌ترین) ✅

1. **Android Studio** را نصب کنید: https://developer.android.com/studio
   (همه‌ی پیش‌نیازها مثل JDK و Android SDK همراهش نصب می‌شوند)
2. Android Studio را باز کنید → **Open** → پوشه‌ی **`android`** این پروژه را انتخاب کنید.
3. چند دقیقه صبر کنید تا **Gradle Sync** تمام شود (نوار پایین پنجره).
4. از منو: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**
5. فایل خروجی اینجاست، آماده‌ی نصب روی گوشی:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```

---

## روش ۲ — با خط فرمان 🖥️

پیش‌نیاز: نصب بودن **JDK 17** و **Android SDK** (متغیر `ANDROID_HOME` تنظیم شده باشد).

```bash
# ویندوز
cd android
gradlew.bat assembleDebug

# مک / لینوکس
cd android
./gradlew assembleDebug
```

خروجی: `android/app/build/outputs/apk/debug/app-debug.apk`

---

## 🔄 بعد از هر تغییر در بازی

هر بار که کد بازی را عوض کردید، این دو دستور را بزنید تا نسخه‌ی جدید وارد پروژه‌ی اندروید شود:

```bash
npm run build
npx cap sync android
```

---

## 🏪 انتشار در کافه‌بازار / گوگل‌پلی

برای انتشار نیاز به **نسخه‌ی امضاشده (Signed Release)** دارید:

1. در Android Studio: **Build → Generate Signed App Bundle / APK**
2. یک **Keystore** بسازید (مراقب فایل و رمزش باشید؛ برای آپدیتهای بعدی لازم است!)
3. خروجی **AAB** برای گوگل‌پلی و **APK** برای کافه‌بازار مناسب است.

---

## 🩹 رفع مشکلات رایج

| مشکل | علت | راه‌حل |
|---|---|---|
| خطای `Could not resolve...` یا `dl.google.com` موقع Gradle Sync | تحریم گوگل — رایج‌ترین مشکل در ایران! | **فیلترشکن روشن کن** و دوباره Sync بزن (File → Sync Project) |
| `JAVA_HOME is not set` یا `java not found` | JDK نصب/تنظیم نیست | Android Studio نصب باشد کافی است؛ از ترمینال استفاده می‌کنی JDK 17 نصب کن و `JAVA_HOME` را ست کن |
| `SDK location not found` / `ANDROID_HOME` | SDK پیدا نمی‌شود | فایل `android/local.properties` بساز و داخلش بنویس: `sdk.dir=C:\\Users\\نام_کاربری\\AppData\\Local\\Android\\Sdk` |
| دانلود Gradle خیلی طولانی | حجم ~۱۰۰ مگ برای بار اول | صبور باش؛ با فیلترشکن معمولاً زیر ۵ دقیقه است |
| کافه‌بازار خطای «امضا» می‌دهد | APK دیباگ را انتخاب کرده‌ای | باید **Signed APK/AAB** بسازی (بخش انتشار بالا) |
| خطای «پکیج‌نیم تکراری» در بازار | شناسه قبلاً گرفته شده | در `capacitor.config.ts` مقدار `appId` را به چیز یکتایی مثل `ir.nini.YOURNAME` تغییر بده، دوباره بیلد + sync کن |
| صفحه‌ی بازی خالی/سفید | نسخه‌ی قدیمی داخل اپ | `npm run build` و بعد `npx cap sync android` و دوباره Build APK |

---

## نکته‌ها 💡

- نام نصب‌شده روی گوشی: **ماجراجویی نی‌نی**
- پکیج‌نیم: `ir.nini.adventure` (قابل تغییر در `capacitor.config.ts`)
- بازی به‌صورت **افقی (Landscape)** قفل شده و **کاملاً آفلاین** کار می‌کند.
- آیکون اختصاری بازی در `resources/icon-src.png` است؛ بعد از تغییرش، دوباره آیکون‌ها را بسازید.
