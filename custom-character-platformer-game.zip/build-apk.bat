@echo off
rem ======================================================
rem  ساخت APK بازی براي ويندوز — فقط دابل‌کلیک کن!
rem  پیش‌نیاز: Node.js نصب باشد + Android Studio نصب باشد
rem  مهم: حتماً فیلترشکن روشن باشد (گریدل باید دانلود کند)
rem ======================================================
chcp 65001 > nul
title ساخت APK — ماجراجویی نی‌نی

echo.
echo  [1/4] بررسی پیش‌نیازها...
where node >nul 2>nul || (echo  [خطا] Node.js نصب نیست! از nodejs.org نصبش کن && pause && exit /b 1)
where java >nul 2>nul || (echo  [هشدار] java در PATH نیست. اندروید استودیو را نصب کرده‌ای؟)

if not defined ANDROID_HOME (
  echo  [هشدار] متغیر ANDROID_HOME تنظیم نشده است!
  echo          معمولاً این است: %%LOCALAPPDATA%%\Android\Sdk
  echo          از Settings ویندوز: Environment Variables -^> New
)

echo.
echo  [2/4] ساخت نسخه‌ی وب بازی...
call npm run build || (echo  [خطا] بیلد وب شکست خورد && pause && exit /b 1)

echo.
echo  [3/4] سینک با پروژه‌ی اندروید...
call npx cap sync android || (echo  [خطا] سینک شکست خورد && pause && exit /b 1)

echo.
echo  [4/4] ساخت APK با Gradle (اولین بار طولانی است — صبور باش!)...
cd android
call gradlew.bat assembleDebug
if errorlevel 1 (
  echo.
  echo  [خطا] ساخت APK ناموفق بود.
  echo  رایج‌ترین علت: گریدل نتوانست از dl.google.com دانلود کند
  echo  راه‌حل: فیلترشکن را روشن کن و دوباره این فایل را اجرا کن.
  pause
  exit /b 1
)

echo.
echo  ==================================================
echo   هورا! APK آماده است:
echo   android\app\build\outputs\apk\debug\app-debug.apk
echo  ==================================================
start "" "app\build\outputs\apk\debug"
pause
