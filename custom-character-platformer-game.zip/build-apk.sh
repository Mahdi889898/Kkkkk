#!/usr/bin/env bash
# ======================================================
#  ساخت APK بازی برای مک/لینوکس — اجرا:  ./build-apk.sh
#  پیش‌نیاز: Node.js + JDK 17 + Android SDK
#  مهم: به dl.google.com دسترسی لازم است
# ======================================================
set -e

echo ""
echo " [1/4] بررسی پیش‌نیازها..."
command -v node >/dev/null || { echo " [خطا] Node.js نصب نیست — nodejs.org"; exit 1; }
command -v java >/dev/null || { echo " [خطا] Java (JDK 17) نصب نیست"; exit 1; }
if [ -z "$ANDROID_HOME" ]; then
  echo " [هشدار] متغیر ANDROID_HOME تنظیم نشده!"
  echo "         معمولاً:  ~/Library/Android/sdk  یا  ~/Android/Sdk"
fi

echo ""
echo " [2/4] ساخت نسخه‌ی وب بازی..."
npm run build

echo ""
echo " [3/4] سینک با پروژه‌ی اندروید..."
npx cap sync android

echo ""
echo " [4/4] ساخت APK با Gradle (اولین بار طولانی است)..."
cd android
chmod +x gradlew
./gradlew assembleDebug || {
  echo ""
  echo " [خطا] ساخت ناموفق بود."
  echo " رایج‌ترین علت: گریدل نتوانست از dl.google.com دانلود کند (تحریم)"
  echo " راه‌حل: فیلترشکن روشن کن و دوباره اجرا کن."
  exit 1
}

echo ""
echo " =================================================="
echo "  هورا! APK آماده است:"
echo "  android/app/build/outputs/apk/debug/app-debug.apk"
echo " =================================================="
