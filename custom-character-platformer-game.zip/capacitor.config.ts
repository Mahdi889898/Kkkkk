import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "ir.nini.adventure",
  appName: "ماجراجویی نی‌نی",
  webDir: "dist",
  backgroundColor: "#bfe3ff",
  android: {
    allowMixedContent: false,
  },
};

export default config;
